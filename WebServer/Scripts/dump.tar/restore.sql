--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE water;
--
-- Name: water; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE water WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Russian_Kazakhstan.1251';


ALTER DATABASE water OWNER TO postgres;

\connect water

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: get_suppliers_by_report_forms_id(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_suppliers_by_report_forms_id(rfid uuid) RETURNS text
    LANGUAGE plpgsql
    AS $$
	Declare rez TEXT;
BEGIN
	select 
	string_agg("Suppliers"."FullName",'; ')
	into rez
	from "Report_Forms" 
	left join "Ref_Katos" on "Ref_Katos"."Id" = "Report_Forms"."RefKatoId"
	left join "ReportSuppliers" on "Report_Forms"."Id" = "ReportSuppliers"."Report_FormId"
	left join "Suppliers" ON "Suppliers"."Id" = "ReportSuppliers"."SupplierId"
	where "Report_Forms"."Id" = rfid
	group by "Suppliers"."FullName"
	;
return rez;
END;
$$;


ALTER FUNCTION public.get_suppliers_by_report_forms_id(rfid uuid) OWNER TO postgres;

--
-- Name: get_val_by_repid_colid(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_val_by_repid_colid(rid uuid, cid uuid) RETURNS text
    LANGUAGE plpgsql
    AS $$
	declare rez text;
BEGIN
	select 
	sum("Data"."ValueJson"::integer)::text into rez
	from "Data"
	where
	"ApproverFormColumnId"=cid and "Data"."ReportFormId"=rid 
    group by "Data"."ValueJson";
return rez;
END;
$$;


ALTER FUNCTION public.get_val_by_repid_colid(rid uuid, cid uuid) OWNER TO postgres;

--
-- Name: getreport2024(); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.getreport2024()
    LANGUAGE plpgsql
    AS $$
BEGIN
    drop table if exists tmp_GetReport2024;
drop table if exists tmp_GetReport2024Hearders;

create temp table tmp_GetReport2024Hearders as
	select 
	'������������ �������, ������' as "1",
	'��� �������, ������ �� �������������� ���������������-��������������� ��������' as "2",
	'������� � ������� (������)' as "3",
	'������������ (��, ���)' as "4",
	'����������� � ��������� ���������� ������� (�������)' as "5",
	'���' as "6",
	'������������' as "7",
	'���������� ���������, ���������� ���������������� �������������� (������)' as "8",
	'���������� ���/��������� (������)' as "9",
	'����������� ��� (������)' as "10",
	'��������� ����������� (������)' as "11",
	'���������� ��������� ������� ������ �  ����������������� ������������� (�������)' as "12"
	;

create temp table tmp_GetReport2024 as 
    select distinct
	"Ref_Katos"."NameRu" as "2",
	"Ref_Katos"."Code" as "3",
	0 as "4",
	0 as "5",
	0 as "6",
	get_suppliers_by_report_forms_id("Report_Forms"."Id") as "7",
	get_suppliers_by_report_forms_id("Report_Forms"."Id") as "8",
	get_val_by_repid_colid("Report_Forms"."Id",'9c78191d-cc63-4c4c-b262-d00526fdae90') as "9",
	0 as "10",
	0 as "11",
	0 as "12",
	get_val_by_repid_colid("Report_Forms"."Id",'12ab9b57-6422-463c-a755-01bcee5f880e') as "13"
	from "Ref_Katos" 
	left join "Report_Forms" on "Ref_Katos"."Id" = "Report_Forms"."RefKatoId"
	left join "ReportSuppliers" on "Report_Forms"."Id" = "ReportSuppliers"."Report_FormId"
	left join "Suppliers" ON "Suppliers"."Id" = "ReportSuppliers"."SupplierId"
	left join "ApprovedForms" on "Report_Forms"."ApprovedFormId" = "ApprovedForms"."Id"
	left join "ApprovedFormItems" on "ApprovedForms"."Id" = "ApprovedFormItems"."ApprovedFormId"
	left join "ApprovedFormItemColumns" on "ApprovedFormItems"."Id" = "ApprovedFormItemColumns"."ApprovedFormItemId"
	left join "Data" on "ApprovedFormItemColumns"."Id" = "Data"."ApproverFormColumnId"
	
	where "Ref_Katos"."KatoLevel" in(1) and "Ref_Katos"."IsDel"=false
order by "Ref_Katos"."Code";
END;
$$;


ALTER PROCEDURE public.getreport2024() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Account_Roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Account_Roles" (
    "Id" uuid NOT NULL,
    "RoleId" integer NOT NULL,
    "AccountId" uuid NOT NULL,
    "AuthorId" uuid,
    "CreateDate" timestamp with time zone,
    "LastModifiedDate" timestamp with time zone,
    "IsDel" boolean NOT NULL,
    "Description" text NOT NULL
);


ALTER TABLE public."Account_Roles" OWNER TO postgres;

--
-- Name: COLUMN "Account_Roles"."Description"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Account_Roles"."Description" IS 'Примечания';


--
-- Name: Accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Accounts" (
    "Id" uuid NOT NULL,
    "Login" text NOT NULL,
    "Bin" text,
    "PasswordHash" text NOT NULL,
    "FullNameRu" text,
    "FullNameKk" text,
    "StreetName" text,
    "BuildingNumber" text,
    "KatoCode" bigint NOT NULL,
    "IsActive" boolean NOT NULL,
    "AuthorId" uuid,
    "CreateDate" timestamp with time zone,
    "LastModifiedDate" timestamp with time zone,
    "IsDel" boolean NOT NULL,
    "Description" text NOT NULL
);


ALTER TABLE public."Accounts" OWNER TO postgres;

--
-- Name: COLUMN "Accounts"."Description"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Accounts"."Description" IS 'Примечания';


--
-- Name: ActionLogs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ActionLogs" (
    "Id" uuid NOT NULL,
    "AccountId" uuid NOT NULL,
    "FormId" uuid NOT NULL,
    "CreateDate" timestamp with time zone NOT NULL,
    "LastModifiedDate" timestamp with time zone NOT NULL,
    "Description" text,
    "Error" text
);


ALTER TABLE public."ActionLogs" OWNER TO postgres;

--
-- Name: ApprovedFormItemColumns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ApprovedFormItemColumns" (
    "Id" uuid NOT NULL,
    "ApprovedFormItemId" uuid NOT NULL,
    "DataType" integer NOT NULL,
    "Length" integer NOT NULL,
    "Nullable" boolean NOT NULL,
    "NameKk" text NOT NULL,
    "NameRu" text NOT NULL,
    "DisplayOrder" integer NOT NULL,
    "ReportCode" text
);


ALTER TABLE public."ApprovedFormItemColumns" OWNER TO postgres;

--
-- Name: COLUMN "ApprovedFormItemColumns"."DataType"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedFormItemColumns"."DataType" IS 'Тип хранимых данных: Label(Просто отображение), IntegerType, DecimalType, StringType, BooleanType, DateType, CalcType';


--
-- Name: COLUMN "ApprovedFormItemColumns"."NameKk"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedFormItemColumns"."NameKk" IS 'Заголовок столбца на казахском';


--
-- Name: COLUMN "ApprovedFormItemColumns"."NameRu"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedFormItemColumns"."NameRu" IS 'Заголовок столбца на русский';


--
-- Name: COLUMN "ApprovedFormItemColumns"."DisplayOrder"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedFormItemColumns"."DisplayOrder" IS 'Порядок отображения';


--
-- Name: COLUMN "ApprovedFormItemColumns"."ReportCode"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedFormItemColumns"."ReportCode" IS 'уникальный код для отчета внутри формы, может дублироваться в других формах';


--
-- Name: ApprovedFormItems; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ApprovedFormItems" (
    "Id" uuid NOT NULL,
    "ApprovedFormId" uuid NOT NULL,
    "ServiceId" integer NOT NULL,
    "Title" text NOT NULL,
    "DisplayOrder" integer NOT NULL,
    "IsVillage" boolean NOT NULL,
    "IsDel" boolean NOT NULL
);


ALTER TABLE public."ApprovedFormItems" OWNER TO postgres;

--
-- Name: COLUMN "ApprovedFormItems"."ServiceId"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedFormItems"."ServiceId" IS 'Сервис. 0 - водоснабжение, 1- водоотведение, 2- водопровод';


--
-- Name: COLUMN "ApprovedFormItems"."Title"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedFormItems"."Title" IS 'Заголовок Формы (короткий)';


--
-- Name: COLUMN "ApprovedFormItems"."DisplayOrder"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedFormItems"."DisplayOrder" IS 'Порядок отображения';


--
-- Name: COLUMN "ApprovedFormItems"."IsVillage"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedFormItems"."IsVillage" IS 'Признак села';


--
-- Name: COLUMN "ApprovedFormItems"."IsDel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedFormItems"."IsDel" IS 'Идентификатор удаления';


--
-- Name: ApprovedForms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ApprovedForms" (
    "Id" uuid NOT NULL,
    "Description" text NOT NULL,
    "ApprovalDate" timestamp with time zone NOT NULL,
    "CompletionDate" timestamp with time zone,
    "IsDel" boolean NOT NULL,
    "DeletedById" uuid
);


ALTER TABLE public."ApprovedForms" OWNER TO postgres;

--
-- Name: COLUMN "ApprovedForms"."Description"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedForms"."Description" IS 'Информация о создании группы форм';


--
-- Name: COLUMN "ApprovedForms"."ApprovalDate"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedForms"."ApprovalDate" IS 'Дата утверждения';


--
-- Name: COLUMN "ApprovedForms"."CompletionDate"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedForms"."CompletionDate" IS 'Дата завершения утвержденной формы';


--
-- Name: COLUMN "ApprovedForms"."IsDel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedForms"."IsDel" IS 'Идентификатор удаления';


--
-- Name: COLUMN "ApprovedForms"."DeletedById"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedForms"."DeletedById" IS 'Идентификатор пользователя удалившего форму';


--
-- Name: Business_Dictionary; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Business_Dictionary" (
    "Id" uuid NOT NULL,
    "ParentId" uuid,
    "Code" text NOT NULL,
    "Type" text NOT NULL,
    "BusinessDecription" text,
    "NameKk" text,
    "NameRu" text,
    "DescriptionKk" text,
    "DescriptionRu" text,
    "IsDel" boolean NOT NULL
);


ALTER TABLE public."Business_Dictionary" OWNER TO postgres;

--
-- Name: COLUMN "Business_Dictionary"."ParentId"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Business_Dictionary"."ParentId" IS 'ключ на ИД (своего типа или стороннего)';


--
-- Name: COLUMN "Business_Dictionary"."Code"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Business_Dictionary"."Code" IS 'Код*';


--
-- Name: COLUMN "Business_Dictionary"."Type"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Business_Dictionary"."Type" IS 'Тип*';


--
-- Name: COLUMN "Business_Dictionary"."BusinessDecription"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Business_Dictionary"."BusinessDecription" IS 'Бизнес описание';


--
-- Name: COLUMN "Business_Dictionary"."NameKk"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Business_Dictionary"."NameKk" IS 'Наименование на каз';


--
-- Name: COLUMN "Business_Dictionary"."NameRu"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Business_Dictionary"."NameRu" IS 'Наименование на рус';


--
-- Name: COLUMN "Business_Dictionary"."DescriptionKk"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Business_Dictionary"."DescriptionKk" IS 'Пояснение на каз';


--
-- Name: COLUMN "Business_Dictionary"."DescriptionRu"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Business_Dictionary"."DescriptionRu" IS 'Пояснение на рус';


--
-- Name: COLUMN "Business_Dictionary"."IsDel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Business_Dictionary"."IsDel" IS 'Удален';


--
-- Name: CityDocuments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CityDocuments" (
    "Id" uuid NOT NULL,
    "CityFormId" uuid,
    "KodNaselPunk" text NOT NULL,
    "KodOblast" text,
    "KodRaiona" text,
    "Login" text,
    "Year" integer NOT NULL
);


ALTER TABLE public."CityDocuments" OWNER TO postgres;

--
-- Name: COLUMN "CityDocuments"."CityFormId"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityDocuments"."CityFormId" IS 'Главная форма город';


--
-- Name: COLUMN "CityDocuments"."KodNaselPunk"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityDocuments"."KodNaselPunk" IS 'Код населенного пункта (КАТО)';


--
-- Name: COLUMN "CityDocuments"."KodOblast"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityDocuments"."KodOblast" IS 'Код обалсти (КАТО)';


--
-- Name: COLUMN "CityDocuments"."KodRaiona"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityDocuments"."KodRaiona" IS 'Код района (КАТО)';


--
-- Name: COLUMN "CityDocuments"."Year"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityDocuments"."Year" IS 'За какой год данные';


--
-- Name: CityForms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CityForms" (
    "Id" uuid NOT NULL,
    "TotalCountCityOblast" integer,
    "TotalCountDomHoz" integer,
    "TotalCountChel" integer,
    "ObslPredpId" uuid
);


ALTER TABLE public."CityForms" OWNER TO postgres;

--
-- Name: COLUMN "CityForms"."TotalCountCityOblast"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityForms"."TotalCountCityOblast" IS 'Общее количество - городов в области (единиц)';


--
-- Name: COLUMN "CityForms"."TotalCountDomHoz"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityForms"."TotalCountDomHoz" IS 'Общее количество - домохозяйств (кв, ИЖД)';


--
-- Name: COLUMN "CityForms"."TotalCountChel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityForms"."TotalCountChel" IS 'Общее количество - проживающих в городских населенных пунктах (человек)';


--
-- Name: COLUMN "CityForms"."ObslPredpId"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityForms"."ObslPredpId" IS 'Обслуживающее предприятие';


--
-- Name: CityNetworkLengths; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CityNetworkLengths" (
    "Id" uuid NOT NULL,
    "IdForm" uuid NOT NULL,
    "VodoProvodLengthTotal" integer,
    "VodoProvodLengthIznos" integer,
    "VodoProvodIznosPercent" numeric,
    "KanalizLengthTotal" integer,
    "KanalizLengthIznos" integer,
    "KanalizIznosPercent" numeric,
    "ObshNewSetiVodo" integer,
    "ObshNewSetiKanaliz" integer,
    "ObshZamenSetiVodo" integer,
    "ObshZamenSetiKanaliz" integer,
    "ObshRemontSetiVodo" integer,
    "ObshRemontSetiKanaliz" integer
);


ALTER TABLE public."CityNetworkLengths" OWNER TO postgres;

--
-- Name: COLUMN "CityNetworkLengths"."VodoProvodLengthTotal"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityNetworkLengths"."VodoProvodLengthTotal" IS 'Протяженность водопроводных сетей, км (по состоянию на конец отчетного года) - общая, км';


--
-- Name: COLUMN "CityNetworkLengths"."VodoProvodLengthIznos"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityNetworkLengths"."VodoProvodLengthIznos" IS 'Протяженность водопроводных сетей, км (по состоянию на конец отчетного года) - в том числе изношенных, км';


--
-- Name: COLUMN "CityNetworkLengths"."VodoProvodIznosPercent"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityNetworkLengths"."VodoProvodIznosPercent" IS 'Протяженность водопроводных сетей, км (по состоянию на конец отчетного года) - Износ, % гр.59/гр.58';


--
-- Name: COLUMN "CityNetworkLengths"."KanalizLengthTotal"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityNetworkLengths"."KanalizLengthTotal" IS 'Протяженность водопроводных сетей, км (по состоянию на конец отчетного года) - общая, км';


--
-- Name: COLUMN "CityNetworkLengths"."KanalizLengthIznos"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityNetworkLengths"."KanalizLengthIznos" IS 'Протяженность канализационных сетей, км (по состоянию на конец отчетного года) - в том числе изношенных, км';


--
-- Name: COLUMN "CityNetworkLengths"."KanalizIznosPercent"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityNetworkLengths"."KanalizIznosPercent" IS 'Протяженность канализационных сетей, км (по состоянию на конец отчетного года) - Износ, % гр.62/гр.61';


--
-- Name: COLUMN "CityNetworkLengths"."ObshNewSetiVodo"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityNetworkLengths"."ObshNewSetiVodo" IS 'Общая протяженность построенных (новых) сетей в отчетном году, км - водоснабжения, км';


--
-- Name: COLUMN "CityNetworkLengths"."ObshNewSetiKanaliz"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityNetworkLengths"."ObshNewSetiKanaliz" IS 'Общая протяженность построенных (новых) сетей в отчетном году, км - водоотведения, км';


--
-- Name: COLUMN "CityNetworkLengths"."ObshZamenSetiVodo"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityNetworkLengths"."ObshZamenSetiVodo" IS 'Общая протяженность реконструированных (замененных) сетей в отчетном году, км - водоснабжения, км';


--
-- Name: COLUMN "CityNetworkLengths"."ObshZamenSetiKanaliz"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityNetworkLengths"."ObshZamenSetiKanaliz" IS 'Общая протяженность реконструированных (замененных) сетей в отчетном году, км - водоотведения, км';


--
-- Name: COLUMN "CityNetworkLengths"."ObshRemontSetiVodo"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityNetworkLengths"."ObshRemontSetiVodo" IS 'Общая протяженность отремонтированных (текущий/капитальный ремонт) сетей в отчетном году, км - водоснабжения, км';


--
-- Name: COLUMN "CityNetworkLengths"."ObshRemontSetiKanaliz"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityNetworkLengths"."ObshRemontSetiKanaliz" IS 'Общая протяженность отремонтированных (текущий/капитальный ремонт) сетей в отчетном году, км - водоотведения, км';


--
-- Name: CityTarifs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CityTarifs" (
    "Id" uuid NOT NULL,
    "IdForm" uuid NOT NULL,
    "VodoSnabUsrednen" integer,
    "VodoSnabFizLic" integer,
    "VodoSnabYriLic" integer,
    "VodoSnabBydzhOrg" integer,
    "VodoOtvedUsred" integer,
    "VodoOtvedFizLic" integer,
    "VodoOtvedYriLic" integer,
    "VodoOtvedBydzhOrg" integer
);


ALTER TABLE public."CityTarifs" OWNER TO postgres;

--
-- Name: COLUMN "CityTarifs"."VodoSnabUsrednen"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityTarifs"."VodoSnabUsrednen" IS 'водоснабжение усредненный, тенге/м3';


--
-- Name: COLUMN "CityTarifs"."VodoSnabFizLic"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityTarifs"."VodoSnabFizLic" IS 'водоснабжение физическим лицам/населению, тенге/м3';


--
-- Name: COLUMN "CityTarifs"."VodoSnabYriLic"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityTarifs"."VodoSnabYriLic" IS 'водоснабжение юридическим лицам, тенге/м3';


--
-- Name: COLUMN "CityTarifs"."VodoSnabBydzhOrg"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityTarifs"."VodoSnabBydzhOrg" IS 'водоснабжение бюджетным организациям, тенге/м3';


--
-- Name: COLUMN "CityTarifs"."VodoOtvedUsred"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityTarifs"."VodoOtvedUsred" IS 'водоотведение - усредненный, тенге/м3';


--
-- Name: COLUMN "CityTarifs"."VodoOtvedFizLic"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityTarifs"."VodoOtvedFizLic" IS 'водоотведение - физическим лицам/населению, тенге/м3';


--
-- Name: COLUMN "CityTarifs"."VodoOtvedYriLic"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityTarifs"."VodoOtvedYriLic" IS 'водоотведение - юридическим лицам, тенге/м3';


--
-- Name: COLUMN "CityTarifs"."VodoOtvedBydzhOrg"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityTarifs"."VodoOtvedBydzhOrg" IS 'водоотведение - бюджетным организациям, тенге/м3';


--
-- Name: CityWaterDisposals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CityWaterDisposals" (
    "Id" uuid NOT NULL,
    "IdForm" uuid NOT NULL,
    "KolAbonent" integer,
    "KolFizLic" integer,
    "KolYriLic" integer,
    "KolBydzhetOrg" integer,
    "KolChelOhvatCentrVodo" integer,
    "DostypCentrVodo" numeric,
    "KolichKanaliz" integer,
    "KolichKanalizMechan" integer,
    "KolichKanalizMechanBiolog" integer,
    "ProizvodKanaliz" integer,
    "IznosKanaliz" numeric,
    "KolChelKanaliz" integer,
    "OhvatChelKanaliz" numeric,
    "FactPostypKanaliz" integer,
    "FactPostypKanaliz1kv" integer,
    "FactPostypKanaliz2kv" integer,
    "FactPostypKanaliz3kv" integer,
    "FactPostypKanaliz4kv" integer,
    "ObiemKanalizNormOchist" integer,
    "UrovenNormOchishVody" integer,
    "AutoProccesSetKanaliz" integer,
    "AutoProccesKanalizNasos" integer,
    "AutoProccesKanalizSooruzh" integer
);


ALTER TABLE public."CityWaterDisposals" OWNER TO postgres;

--
-- Name: COLUMN "CityWaterDisposals"."KolAbonent"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."KolAbonent" IS 'Кол-во абонентов, охваченных централизованным водоотведением (единиц)';


--
-- Name: COLUMN "CityWaterDisposals"."KolFizLic"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."KolFizLic" IS 'Кол-во абонентов, охваченных централизованным водоотведением (единиц) - физических лиц/население (единиц)';


--
-- Name: COLUMN "CityWaterDisposals"."KolYriLic"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."KolYriLic" IS 'Кол-во абонентов, охваченных централизованным водоотведением (единиц) - юридических лиц (единиц)';


--
-- Name: COLUMN "CityWaterDisposals"."KolBydzhetOrg"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."KolBydzhetOrg" IS 'Кол-во абонентов, охваченных централизованным водоотведением (единиц) - бюджетных организаций (единиц)';


--
-- Name: COLUMN "CityWaterDisposals"."KolChelOhvatCentrVodo"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."KolChelOhvatCentrVodo" IS 'Численность населения, охваченного централизованным водоотведением, (человек)';


--
-- Name: COLUMN "CityWaterDisposals"."DostypCentrVodo"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."DostypCentrVodo" IS 'Доступ к централизованному водоотведению, в % гр.31/гр.6*100';


--
-- Name: COLUMN "CityWaterDisposals"."KolichKanaliz"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."KolichKanaliz" IS 'Наличие канализационно-очистных сооружений, (единиц)';


--
-- Name: COLUMN "CityWaterDisposals"."KolichKanalizMechan"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."KolichKanalizMechan" IS 'Наличие канализационно-очистных сооружений, (единиц) - только с механичес-кой очисткой (еди-ниц)';


--
-- Name: COLUMN "CityWaterDisposals"."KolichKanalizMechanBiolog"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."KolichKanalizMechanBiolog" IS 'Наличие канализационно-очистных сооружений, (единиц) - с механической и биологической очист-кой (еди-ниц)';


--
-- Name: COLUMN "CityWaterDisposals"."ProizvodKanaliz"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."ProizvodKanaliz" IS 'Производительность канализационно-очистных сооружений (проектная)';


--
-- Name: COLUMN "CityWaterDisposals"."IznosKanaliz"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."IznosKanaliz" IS 'Износ канализационно-очистных сооружений, в %';


--
-- Name: COLUMN "CityWaterDisposals"."KolChelKanaliz"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."KolChelKanaliz" IS 'Численность населения, охваченного действующими канализационно-очистными сооружениями, (человек)';


--
-- Name: COLUMN "CityWaterDisposals"."OhvatChelKanaliz"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."OhvatChelKanaliz" IS 'Охват населения очисткой сточных вод, в % гр.38/гр.6*100';


--
-- Name: COLUMN "CityWaterDisposals"."FactPostypKanaliz"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."FactPostypKanaliz" IS 'Фактически поступило сточных вод в канализационно-очистные сооружения (тыс.м3)';


--
-- Name: COLUMN "CityWaterDisposals"."FactPostypKanaliz1kv"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."FactPostypKanaliz1kv" IS 'Фактически поступило сточных вод в канализационно-очистные сооружения (тыс.м3) - За I квартал (тыс.м3)';


--
-- Name: COLUMN "CityWaterDisposals"."FactPostypKanaliz2kv"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."FactPostypKanaliz2kv" IS 'Фактически поступило сточных вод в канализационно-очистные сооружения (тыс.м3) - За II квартал (тыс.м3)';


--
-- Name: COLUMN "CityWaterDisposals"."FactPostypKanaliz3kv"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."FactPostypKanaliz3kv" IS 'Фактически поступило сточных вод в канализационно-очистные сооружения (тыс.м3) - За III квартал (тыс.м3)';


--
-- Name: COLUMN "CityWaterDisposals"."FactPostypKanaliz4kv"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."FactPostypKanaliz4kv" IS 'Фактически поступило сточных вод в канализационно-очистные сооружения (тыс.м3) - За IV квартал (тыс.м3)';


--
-- Name: COLUMN "CityWaterDisposals"."ObiemKanalizNormOchist"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."ObiemKanalizNormOchist" IS 'Объем сточных вод, соответствующей нормативной очистке по собственному лабораторному мониторингу за отчетный период (тыс.м3)';


--
-- Name: COLUMN "CityWaterDisposals"."UrovenNormOchishVody"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."UrovenNormOchishVody" IS 'Уровень нормативно- очищенной воды, % гр.45/гр.40 * 100';


--
-- Name: COLUMN "CityWaterDisposals"."AutoProccesSetKanaliz"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."AutoProccesSetKanaliz" IS 'Автоматизация производственных процессов водоотведения и наличие централизованной системы контроля и управления (SCADA) - Сети канализации (0 или 1)';


--
-- Name: COLUMN "CityWaterDisposals"."AutoProccesKanalizNasos"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."AutoProccesKanalizNasos" IS 'Автоматизация производственных процессов водоотведения и наличие централизованной системы контроля и управления (SCADA) - Канализационные насосные станции (0 или 1)';


--
-- Name: COLUMN "CityWaterDisposals"."AutoProccesKanalizSooruzh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterDisposals"."AutoProccesKanalizSooruzh" IS 'Автоматизация производственных процессов водоотведения и наличие централизованной системы контроля и управления (SCADA) - Канализационно-очистные сооружения (0 или 1)';


--
-- Name: CityWaterSupplies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CityWaterSupplies" (
    "Id" uuid NOT NULL,
    "IdForm" uuid NOT NULL,
    "KolichAbonent" integer,
    "KolFizLic" integer,
    "KolYriLic" integer,
    "KolBydzhOrg" integer,
    "KolChelDostyp" integer,
    "ObespechCentrlVodo" numeric,
    "IndivUchetVodyVsego" integer,
    "IndivUchetVodyDistance" integer,
    "IndivUchetVodyPercent" numeric,
    "ObshePodlezhashKolZdan" integer,
    "ObsheUstanKolZdan" integer,
    "ObsheUstanPriborKol" integer,
    "ObsheUstanDistanceKol" integer,
    "ObsheOhvatPercent" numeric,
    "AutoProccesVodoZabor" integer,
    "AutoProccesVodoPodgot" integer,
    "AutoProccesNasosStanc" integer,
    "AutoProccesSetVodosnab" integer
);


ALTER TABLE public."CityWaterSupplies" OWNER TO postgres;

--
-- Name: COLUMN "CityWaterSupplies"."KolichAbonent"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterSupplies"."KolichAbonent" IS 'Количество абонентов, охваченных централизованным водоснабжением (единиц)';


--
-- Name: COLUMN "CityWaterSupplies"."KolFizLic"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterSupplies"."KolFizLic" IS 'физических лиц/население (единиц)';


--
-- Name: COLUMN "CityWaterSupplies"."KolYriLic"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterSupplies"."KolYriLic" IS 'юридических лиц (единиц)';


--
-- Name: COLUMN "CityWaterSupplies"."KolBydzhOrg"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterSupplies"."KolBydzhOrg" IS 'бюджетных организаций (единиц)';


--
-- Name: COLUMN "CityWaterSupplies"."KolChelDostyp"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterSupplies"."KolChelDostyp" IS 'Количество населения имеющих доступ к  централизованному водоснабжению (человек)';


--
-- Name: COLUMN "CityWaterSupplies"."ObespechCentrlVodo"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterSupplies"."ObespechCentrlVodo" IS 'Обеспеченность централизованным водоснабжением, в % гр.13/гр.6 *100';


--
-- Name: COLUMN "CityWaterSupplies"."IndivUchetVodyVsego"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterSupplies"."IndivUchetVodyVsego" IS 'Охват индивидуальными приборами учета воды по состоянию на конец отчетного года - всего с нарастающим (единиц)';


--
-- Name: COLUMN "CityWaterSupplies"."IndivUchetVodyDistance"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterSupplies"."IndivUchetVodyDistance" IS 'Охват индивидуальными приборами учета воды по состоянию на конец отчетного года - в том числе с дистанционной передачей данных в АСУЭ обслуживающего предприятия (единиц)';


--
-- Name: COLUMN "CityWaterSupplies"."IndivUchetVodyPercent"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterSupplies"."IndivUchetVodyPercent" IS 'Охват индивидуальными приборами учета воды по состоянию на конец отчетного года - охват в %, гр.15/гр. 9*100';


--
-- Name: COLUMN "CityWaterSupplies"."ObshePodlezhashKolZdan"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterSupplies"."ObshePodlezhashKolZdan" IS 'Охват общедомовыми приборами учета воды по состоянию на конец отчетного года - Количество зданий и сооружений, подлежащих к установке общедомовых приборов учета (единиц)';


--
-- Name: COLUMN "CityWaterSupplies"."ObsheUstanKolZdan"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterSupplies"."ObsheUstanKolZdan" IS 'Охват общедомовыми приборами учета воды по состоянию на конец отчетного года - Количество зданий и сооружений с установленными общедомовыми приборами учета (единиц)';


--
-- Name: COLUMN "CityWaterSupplies"."ObsheUstanPriborKol"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterSupplies"."ObsheUstanPriborKol" IS 'Охват общедомовыми приборами учета воды по состоянию на конец отчетного года - Количество установленных общедомовых приборов учета (единиц)';


--
-- Name: COLUMN "CityWaterSupplies"."ObsheUstanDistanceKol"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterSupplies"."ObsheUstanDistanceKol" IS 'Охват общедомовыми приборами учета воды по состоянию на конец отчетного года - в том числе с дистанционной передачей данных в АСУЭ обслуживающего предприятия (единиц)';


--
-- Name: COLUMN "CityWaterSupplies"."ObsheOhvatPercent"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterSupplies"."ObsheOhvatPercent" IS 'Охват общедомовыми приборами учета воды по состоянию на конец отчетного года - охват в %, гр.19/гр. 18*100';


--
-- Name: COLUMN "CityWaterSupplies"."AutoProccesVodoZabor"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterSupplies"."AutoProccesVodoZabor" IS 'Автоматизация производственных процессов водоснабжения и наличие централизованной системы контроля и управления (SCADA) - Водозабор (0 или 1)';


--
-- Name: COLUMN "CityWaterSupplies"."AutoProccesVodoPodgot"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterSupplies"."AutoProccesVodoPodgot" IS 'Автоматизация производственных процессов водоснабжения и наличие централизованной системы контроля и управления (SCADA) - Водоподготовка (0 или 1)';


--
-- Name: COLUMN "CityWaterSupplies"."AutoProccesNasosStanc"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterSupplies"."AutoProccesNasosStanc" IS 'Автоматизация производственных процессов водоснабжения и наличие централизованной системы контроля и управления (SCADA) - Насосные станции (0 или 1)';


--
-- Name: COLUMN "CityWaterSupplies"."AutoProccesSetVodosnab"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."CityWaterSupplies"."AutoProccesSetVodosnab" IS 'Автоматизация производственных процессов водоснабжения и наличие централизованной системы контроля и управления (SCADA) - Сети водоснабжения (0 или 1)';


--
-- Name: ColumnLayouts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ColumnLayouts" (
    "Id" uuid NOT NULL,
    "ApprovedFormItemColumnId" uuid NOT NULL,
    "Height" integer,
    "Width" integer,
    "Position" text
);


ALTER TABLE public."ColumnLayouts" OWNER TO postgres;

--
-- Name: Consumers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Consumers" (
    "Id" uuid NOT NULL,
    "SupplierId" uuid NOT NULL,
    "Ref_KatoId" integer
);


ALTER TABLE public."Consumers" OWNER TO postgres;

--
-- Name: Data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Data" (
    "Id" uuid NOT NULL,
    "ApprovedFormId" uuid NOT NULL,
    "ApprovedFormItemId" uuid NOT NULL,
    "ApproverFormColumnId" uuid NOT NULL,
    "ReportFormId" uuid NOT NULL,
    "ValueType" integer NOT NULL,
    "ValueJson" text NOT NULL,
    "AuthorId" uuid,
    "CreateDate" timestamp with time zone,
    "LastModifiedDate" timestamp with time zone,
    "IsDel" boolean NOT NULL,
    "Description" text NOT NULL
);


ALTER TABLE public."Data" OWNER TO postgres;

--
-- Name: COLUMN "Data"."Description"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Data"."Description" IS 'Примечания';


--
-- Name: Pipelines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Pipelines" (
    "Id" uuid NOT NULL,
    "FormId" uuid NOT NULL,
    "TotalPipelineLength" numeric NOT NULL,
    "WornPipelineLength" numeric NOT NULL,
    "TotalSewerNetworkLength" numeric NOT NULL,
    "WornSewerNetworkLength" numeric NOT NULL,
    "NewWaterSupplyNetworkLength" numeric NOT NULL,
    "NewWastewaterNetworkLength" numeric NOT NULL,
    "ReconstructedNetworkLength" numeric NOT NULL,
    "ReconstructedWastewaterNetworkLength" numeric NOT NULL,
    "RepairedWaterSupplyNetworkLength" numeric NOT NULL,
    "RepairedWastewaterNetworkLength" numeric NOT NULL,
    "TotalPopulation" numeric NOT NULL,
    "AuthorId" uuid,
    "CreateDate" timestamp with time zone,
    "LastModifiedDate" timestamp with time zone,
    "IsDel" boolean NOT NULL,
    "Description" text NOT NULL
);


ALTER TABLE public."Pipelines" OWNER TO postgres;

--
-- Name: COLUMN "Pipelines"."TotalPipelineLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."TotalPipelineLength" IS 'Протяженность водопроводных сетей, км (по состоянию на конец отчетного года),общая, км';


--
-- Name: COLUMN "Pipelines"."WornPipelineLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."WornPipelineLength" IS 'в том числе изношенных, км';


--
-- Name: COLUMN "Pipelines"."TotalSewerNetworkLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."TotalSewerNetworkLength" IS 'Протяженность канализационных сетей, км (по состоянию на конец отчетного года),общая, км';


--
-- Name: COLUMN "Pipelines"."WornSewerNetworkLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."WornSewerNetworkLength" IS 'в том числе изношенных, км';


--
-- Name: COLUMN "Pipelines"."NewWaterSupplyNetworkLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."NewWaterSupplyNetworkLength" IS 'Общая протяженность построенных (новых) сетей в отчетном году, км, водоснабжения, км';


--
-- Name: COLUMN "Pipelines"."NewWastewaterNetworkLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."NewWastewaterNetworkLength" IS 'водоотведения, км';


--
-- Name: COLUMN "Pipelines"."ReconstructedNetworkLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."ReconstructedNetworkLength" IS 'Общая протяженность реконструированных (замененных) сетей в отчетном году, км, водоснабжения, км';


--
-- Name: COLUMN "Pipelines"."ReconstructedWastewaterNetworkLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."ReconstructedWastewaterNetworkLength" IS 'водоотведения, км';


--
-- Name: COLUMN "Pipelines"."RepairedWaterSupplyNetworkLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."RepairedWaterSupplyNetworkLength" IS 'Общая протяженность отремонтированных (текущий/капитальный ремонт) сетей в отчетном году, км, водоснабжения, км';


--
-- Name: COLUMN "Pipelines"."RepairedWastewaterNetworkLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."RepairedWastewaterNetworkLength" IS 'водоотведения, км';


--
-- Name: COLUMN "Pipelines"."TotalPopulation"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."TotalPopulation" IS 'численность населения (вся)';


--
-- Name: COLUMN "Pipelines"."Description"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."Description" IS 'Примечания';


--
-- Name: Ref_Access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Ref_Access" (
    "Id" integer NOT NULL,
    "NameRu" text NOT NULL,
    "CodeAccessName" text NOT NULL,
    "TypeAccessName" text NOT NULL,
    "ActionName" text NOT NULL,
    "NameKk" text,
    "IsDel" boolean NOT NULL,
    "Description" text
);


ALTER TABLE public."Ref_Access" OWNER TO postgres;

--
-- Name: COLUMN "Ref_Access"."NameRu"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Ref_Access"."NameRu" IS 'Наименование доступа';


--
-- Name: COLUMN "Ref_Access"."CodeAccessName"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Ref_Access"."CodeAccessName" IS 'Код доступа';


--
-- Name: COLUMN "Ref_Access"."TypeAccessName"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Ref_Access"."TypeAccessName" IS 'Тип доступа';


--
-- Name: COLUMN "Ref_Access"."ActionName"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Ref_Access"."ActionName" IS 'Действие';


--
-- Name: Ref_Access_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Ref_Access" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."Ref_Access_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Ref_Buildings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Ref_Buildings" (
    "Id" integer NOT NULL,
    "RefStreetId" integer NOT NULL,
    "Building" text NOT NULL,
    "NameRu" text NOT NULL,
    "NameKk" text,
    "IsDel" boolean NOT NULL,
    "Description" text
);


ALTER TABLE public."Ref_Buildings" OWNER TO postgres;

--
-- Name: Ref_Buildings_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Ref_Buildings" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."Ref_Buildings_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Ref_Katos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Ref_Katos" (
    "Id" integer NOT NULL,
    "ParentId" integer NOT NULL,
    "Code" bigint NOT NULL,
    "Latitude" numeric,
    "Longitude" numeric,
    "UserId" uuid,
    "IsReportable" boolean NOT NULL,
    "KatoLevel" integer,
    "ParentRaion" integer,
    "ParentObl" integer,
    "NameRu" text NOT NULL,
    "NameKk" text,
    "IsDel" boolean NOT NULL,
    "Description" text
);


ALTER TABLE public."Ref_Katos" OWNER TO postgres;

--
-- Name: COLUMN "Ref_Katos"."KatoLevel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Ref_Katos"."KatoLevel" IS 'Категории населенных пунктов. 0-область,1-город,2-село,3-район';


--
-- Name: COLUMN "Ref_Katos"."ParentRaion"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Ref_Katos"."ParentRaion" IS 'Если это район, он смотрит сам на себя, если это село, код района,';


--
-- Name: COLUMN "Ref_Katos"."ParentObl"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Ref_Katos"."ParentObl" IS 'Область Астана,Алматы...сам на себя ссылка, если район код области';


--
-- Name: Ref_Katos_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Ref_Katos" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."Ref_Katos_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Ref_Role_Access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Ref_Role_Access" (
    "Id" integer NOT NULL,
    "RoleId" integer NOT NULL,
    "AccessId" integer NOT NULL,
    "NameRu" text NOT NULL,
    "NameKk" text,
    "IsDel" boolean NOT NULL,
    "Description" text
);


ALTER TABLE public."Ref_Role_Access" OWNER TO postgres;

--
-- Name: COLUMN "Ref_Role_Access"."RoleId"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Ref_Role_Access"."RoleId" IS 'Айди roles';


--
-- Name: Ref_Role_Access_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Ref_Role_Access" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."Ref_Role_Access_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Ref_Roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Ref_Roles" (
    "Id" integer NOT NULL,
    "Code" text NOT NULL,
    "TypeName" text NOT NULL,
    "NameRu" text NOT NULL,
    "NameKk" text,
    "IsDel" boolean NOT NULL,
    "Description" text
);


ALTER TABLE public."Ref_Roles" OWNER TO postgres;

--
-- Name: COLUMN "Ref_Roles"."Code"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Ref_Roles"."Code" IS 'Код роли';


--
-- Name: COLUMN "Ref_Roles"."TypeName"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Ref_Roles"."TypeName" IS 'Тип роли';


--
-- Name: Ref_Roles_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Ref_Roles" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."Ref_Roles_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Ref_Statuses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Ref_Statuses" (
    "Id" integer NOT NULL,
    "NameRu" text NOT NULL,
    "NameKk" text,
    "IsDel" boolean NOT NULL,
    "Description" text
);


ALTER TABLE public."Ref_Statuses" OWNER TO postgres;

--
-- Name: Ref_Statuses_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Ref_Statuses" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."Ref_Statuses_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Ref_Streets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Ref_Streets" (
    "Id" integer NOT NULL,
    "RefKatoId" integer NOT NULL,
    "NameRu" text NOT NULL,
    "NameKk" text,
    "IsDel" boolean NOT NULL,
    "Description" text
);


ALTER TABLE public."Ref_Streets" OWNER TO postgres;

--
-- Name: Ref_Streets_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Ref_Streets" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."Ref_Streets_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ReportSuppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ReportSuppliers" (
    "Id" uuid NOT NULL,
    "Report_FormId" uuid NOT NULL,
    "SupplierId" uuid NOT NULL,
    "ServiceId" integer NOT NULL,
    "AuthorId" uuid,
    "CreateDate" timestamp with time zone,
    "LastModifiedDate" timestamp with time zone,
    "IsDel" boolean NOT NULL,
    "Description" text NOT NULL
);


ALTER TABLE public."ReportSuppliers" OWNER TO postgres;

--
-- Name: COLUMN "ReportSuppliers"."Description"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ReportSuppliers"."Description" IS 'Примечания';


--
-- Name: Report_Forms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Report_Forms" (
    "Id" uuid NOT NULL,
    "ApprovedFormId" uuid NOT NULL,
    "RefKatoId" integer NOT NULL,
    "ReportYearId" integer NOT NULL,
    "ReportMonthId" integer NOT NULL,
    "RefStatusId" integer NOT NULL,
    "HasStreets" boolean NOT NULL,
    "AuthorId" uuid,
    "CreateDate" timestamp with time zone,
    "LastModifiedDate" timestamp with time zone,
    "IsDel" boolean NOT NULL,
    "Description" text NOT NULL
);


ALTER TABLE public."Report_Forms" OWNER TO postgres;

--
-- Name: COLUMN "Report_Forms"."HasStreets"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Report_Forms"."HasStreets" IS 'Наличие улиц в селе';


--
-- Name: COLUMN "Report_Forms"."Description"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Report_Forms"."Description" IS 'Примечания';


--
-- Name: ResponseCodes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ResponseCodes" (
    "Id" integer NOT NULL,
    "NameCode" text NOT NULL,
    "DescriptionCode" text NOT NULL,
    "BeginDate" timestamp with time zone NOT NULL,
    "EndDate" timestamp with time zone
);


ALTER TABLE public."ResponseCodes" OWNER TO postgres;

--
-- Name: ResponseCodes_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."ResponseCodes" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."ResponseCodes_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: SeloDocuments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SeloDocuments" (
    "Id" uuid NOT NULL,
    "SeloFormId" uuid,
    "KodNaselPunk" text,
    "KodOblast" text,
    "KodRaiona" text,
    "Login" text,
    "Year" integer NOT NULL
);


ALTER TABLE public."SeloDocuments" OWNER TO postgres;

--
-- Name: COLUMN "SeloDocuments"."SeloFormId"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloDocuments"."SeloFormId" IS 'Главная форма город';


--
-- Name: COLUMN "SeloDocuments"."KodNaselPunk"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloDocuments"."KodNaselPunk" IS 'Код населенного пункта (КАТО)';


--
-- Name: COLUMN "SeloDocuments"."KodOblast"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloDocuments"."KodOblast" IS 'Код обалсти (КАТО)';


--
-- Name: COLUMN "SeloDocuments"."KodRaiona"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloDocuments"."KodRaiona" IS 'Код района (КАТО)';


--
-- Name: COLUMN "SeloDocuments"."Year"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloDocuments"."Year" IS 'За какой год данные';


--
-- Name: SeloForms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SeloForms" (
    "Id" uuid NOT NULL,
    "StatusOpor" boolean,
    "StatusSput" boolean,
    "StatusProch" text,
    "StatusPrigran" boolean,
    "ObshKolSelNasPun" integer,
    "ObshKolChelNasPun" integer,
    "ObshKolDomHoz" integer,
    "YearSystVodoSnab" text,
    "ObslPredpId" uuid,
    "SobstId" uuid,
    "DosVodoSnabKolPunk" integer,
    "DosVodoSnabKolChel" integer,
    "DosVodoSnabPercent" numeric,
    "CentrVodoSnabKolNasPun" integer,
    "CentrVodoSnabKolChel" integer,
    "CentrVodoSnabObesKolNasPunk" numeric,
    "CentrVodoSnabObesKolChel" numeric,
    "CentrVodoSnabKolAbon" integer,
    "CentrVodoSnabFizLic" integer,
    "CentrVodoSnabYriLic" integer,
    "CentrVodoSnabBudzhOrg" integer,
    "CentrVodoIndivPriborUchVodyVsego" integer,
    "CentrVodoIndivPriborUchVodyASYE" integer,
    "CentrVodoIndivPriborUchVodyOhvat" numeric,
    "NeCtentrVodoKolSelsNasPunk" integer,
    "KbmKolSelsNasPunk" integer,
    "KbmKolChel" integer,
    "KbmObespNasel" numeric,
    "PrvKolSelsNasPunk" integer,
    "PrvKolChel" integer,
    "PrvObespNasel" numeric,
    "PrivVodaKolSelsNasPunk" integer,
    "PrivVodaKolChel" integer,
    "PrivVodaObespNasel" numeric,
    "SkvazhKolSelsNasPunk" integer,
    "SkvazhKolChel" integer,
    "SkvazhObespNasel" numeric,
    "SkvazhKolSelsNasPunkOtkaz" integer,
    "SkvazhKolChelOtkaz" integer,
    "SkvazhDolyaNaselOtkaz" numeric,
    "SkvazhDolyaSelOtkaz" numeric,
    "CentrVodOtvedKolSelsNasPunk" integer,
    "CentrVodOtvedKolChel" integer,
    "CentrVodOtvedKolAbonent" integer,
    "CentrVodOtvedFizLic" integer,
    "CentrVodOtvedYriLic" integer,
    "CentrVodOtvedBydzhOrg" integer,
    "CentrVodOtvedDostypKolNasPunk" numeric,
    "CentrVodOtvedDostypKolChel" numeric,
    "CentrVodOtvedNalich" integer,
    "CentrVodOtvedNalichMechan" integer,
    "CentrVodOtvedNalichMechanBiolog" integer,
    "CentrVodOtvedProizvod" integer,
    "CentrVodOtvedIznos" numeric,
    "CentrVodOtvedOhvatKolChel" integer,
    "CentrVodOtvedOhvatNasel" numeric,
    "CentrVodOtvedFactPostypStochVod" integer,
    "CentrVodOtvedFactPostypStochVod1" integer,
    "CentrVodOtvedFactPostypStochVod2" integer,
    "CentrVodOtvedFactPostypStochVod3" integer,
    "CentrVodOtvedFactPostypStochVod4" integer,
    "CentrVodOtvedObiemStochVod" integer,
    "CentrVodOtvedUrovenNorm" numeric,
    "DecentrVodoOtvedKolSelsNasPunk" integer,
    "DecentrVodoOtvedKolChel" integer,
    "TarifVodoSnabUsred" integer,
    "TarifVodoSnabFizL" integer,
    "TarifVodoSnabYriL" integer,
    "TarifVodoSnabBudzh" integer,
    "TarifVodoOtvedUsred" integer,
    "TarifVodoOtvedFizL" integer,
    "TarifVodoOtvedYriL" integer,
    "TarifVodoOtvedBudzh" integer,
    "ProtyzhVodoSeteyObsh" integer,
    "ProtyzhVodoSeteyVtomIznos" integer,
    "ProtyzhVodoSeteyIznos" numeric,
    "ProtyzhKanalSeteyObsh" integer,
    "ProtyzhKanalSeteyVtomIznos" integer,
    "ProtyzhKanalSeteyIznos" numeric,
    "ProtyzhNewSeteyVodoSnab" integer,
    "ProtyzhNewSeteyVodoOtved" integer,
    "ProtyzhRekonSeteyVodoSnab" integer,
    "ProtyzhRekonSeteyVodoOtved" integer,
    "ProtyzhRemontSeteyVodoSnab" integer,
    "ProtyzhRemontSeteyVodoOtved" integer
);


ALTER TABLE public."SeloForms" OWNER TO postgres;

--
-- Name: COLUMN "SeloForms"."StatusOpor"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."StatusOpor" IS 'Статус села опорное';


--
-- Name: COLUMN "SeloForms"."StatusSput"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."StatusSput" IS 'Статус села спутниковое';


--
-- Name: COLUMN "SeloForms"."StatusProch"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."StatusProch" IS 'Статус села прочие';


--
-- Name: COLUMN "SeloForms"."StatusPrigran"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."StatusPrigran" IS 'Статус села приграничные';


--
-- Name: COLUMN "SeloForms"."ObshKolSelNasPun"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."ObshKolSelNasPun" IS 'Общее количество сельских населенных пунктов в области(единиц)';


--
-- Name: COLUMN "SeloForms"."ObshKolChelNasPun"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."ObshKolChelNasPun" IS 'Общая численность населения в сельских населенных пунктах (человек)';


--
-- Name: COLUMN "SeloForms"."ObshKolDomHoz"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."ObshKolDomHoz" IS 'Общее количество домохозяйств (квартир, ИЖД)';


--
-- Name: COLUMN "SeloForms"."YearSystVodoSnab"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."YearSystVodoSnab" IS 'Год постройки системы водоснабжения';


--
-- Name: COLUMN "SeloForms"."ObslPredpId"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."ObslPredpId" IS 'Обслуживающее предприятие';


--
-- Name: COLUMN "SeloForms"."SobstId"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."SobstId" IS 'в чьей собственности находится';


--
-- Name: COLUMN "SeloForms"."DosVodoSnabKolPunk"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."DosVodoSnabKolPunk" IS 'Доступ населения к услугам водоснабжения Количество сельских населенных пунктов (единиц)';


--
-- Name: COLUMN "SeloForms"."DosVodoSnabKolChel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."DosVodoSnabKolChel" IS 'Доступ населения к услугам водоснабжения Численность населения, проживающего в данных сельских населенных пунктах (человек)';


--
-- Name: COLUMN "SeloForms"."DosVodoSnabPercent"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."DosVodoSnabPercent" IS 'Доступ населения к услугам водоснабжения, %';


--
-- Name: COLUMN "SeloForms"."CentrVodoSnabKolNasPun"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodoSnabKolNasPun" IS 'Кол-во сельских населенных пунктов (единиц)';


--
-- Name: COLUMN "SeloForms"."CentrVodoSnabKolChel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodoSnabKolChel" IS 'Численность населения, проживающего в данных сельских населенных пунктах (человек)';


--
-- Name: COLUMN "SeloForms"."CentrVodoSnabObesKolNasPunk"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodoSnabObesKolNasPunk" IS 'Обеспеченность централизованным водоснабжением по количеству сельских населенных пунктов, % гр.19/гр.8 *100';


--
-- Name: COLUMN "SeloForms"."CentrVodoSnabObesKolChel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodoSnabObesKolChel" IS 'Обеспеченность централизованным водоснабжением по численности населения, % гр.20/гр.9 *100';


--
-- Name: COLUMN "SeloForms"."CentrVodoSnabKolAbon"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodoSnabKolAbon" IS 'Кол-во абонентов, охваченных централизованным водоснабжением (единиц)';


--
-- Name: COLUMN "SeloForms"."CentrVodoSnabFizLic"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodoSnabFizLic" IS 'в том числе физических лиц/население (единиц)';


--
-- Name: COLUMN "SeloForms"."CentrVodoSnabYriLic"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodoSnabYriLic" IS 'в том числе юридических лиц (единиц)';


--
-- Name: COLUMN "SeloForms"."CentrVodoSnabBudzhOrg"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodoSnabBudzhOrg" IS 'в том числе бюджетных организаций (единиц)';


--
-- Name: COLUMN "SeloForms"."CentrVodoIndivPriborUchVodyVsego"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodoIndivPriborUchVodyVsego" IS 'Всего установлено индивидуальных приборов учета воды по состоянию на конец отчетного года (единиц)';


--
-- Name: COLUMN "SeloForms"."CentrVodoIndivPriborUchVodyASYE"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodoIndivPriborUchVodyASYE" IS 'в том числе с дистанционной передачей данных в АСУЭ обслуживающего предприятия (единиц)';


--
-- Name: COLUMN "SeloForms"."CentrVodoIndivPriborUchVodyOhvat"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodoIndivPriborUchVodyOhvat" IS 'Охват индивидуальными приборами учета воды, % гр.27/гр. 23*100';


--
-- Name: COLUMN "SeloForms"."NeCtentrVodoKolSelsNasPunk"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."NeCtentrVodoKolSelsNasPunk" IS 'Нецентрализованное водоснабжение Количество сельских населенных пунктов (единиц)';


--
-- Name: COLUMN "SeloForms"."KbmKolSelsNasPunk"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."KbmKolSelsNasPunk" IS 'Нецентрализованное водоснабжение КБМ Количество сельских населенных пунктов, где установлено КБМ';


--
-- Name: COLUMN "SeloForms"."KbmKolChel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."KbmKolChel" IS 'Нецентрализованное водоснабжение КБМ Численность населения, проживающего в сельских населенных пунктах, где установлены КБМ (человек)';


--
-- Name: COLUMN "SeloForms"."KbmObespNasel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."KbmObespNasel" IS 'Нецентрализованное водоснабжение КБМ Обеспеченность населения услугами КБМ, % гр.32/гр.9*100';


--
-- Name: COLUMN "SeloForms"."PrvKolSelsNasPunk"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."PrvKolSelsNasPunk" IS 'Нецентрализованное водоснабжение ПРВ Количество сельских населенных пунктов, где установлено ПРВ';


--
-- Name: COLUMN "SeloForms"."PrvKolChel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."PrvKolChel" IS 'Нецентрализованное водоснабжение ПРВ Численность населения, проживающего в сельских населенных пунктах, где установлены ПРВ (человек)';


--
-- Name: COLUMN "SeloForms"."PrvObespNasel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."PrvObespNasel" IS 'Нецентрализованное водоснабжение ПРВ Обеспеченность населения услугами  ПРВ, % гр.35/гр.9*100';


--
-- Name: COLUMN "SeloForms"."PrivVodaKolSelsNasPunk"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."PrivVodaKolSelsNasPunk" IS 'Нецентрализованное водоснабжение Привозная вода Количество сельских населенных пунктов, жители которых используют привозную воду';


--
-- Name: COLUMN "SeloForms"."PrivVodaKolChel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."PrivVodaKolChel" IS 'Нецентрализованное водоснабжение Привозная вода Численность населения, проживающего в сельских населенных пунктах, где используют привозную воду';


--
-- Name: COLUMN "SeloForms"."PrivVodaObespNasel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."PrivVodaObespNasel" IS 'Нецентрализованное водоснабжение Привозная вода Обеспеченность населения привозной водой, % гр.38/гр.9*100';


--
-- Name: COLUMN "SeloForms"."SkvazhKolSelsNasPunk"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."SkvazhKolSelsNasPunk" IS 'Нецентрализованное водоснабжение Скважины, колодцы Количество сельских населенных пунктов, жители которых используют воду из скважин и колодцов';


--
-- Name: COLUMN "SeloForms"."SkvazhKolChel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."SkvazhKolChel" IS 'Нецентрализованное водоснабжение Скважины, колодцы Численность населения, проживающего в сельских населенных пунктах, где используют  воду из скважин и колодцев';


--
-- Name: COLUMN "SeloForms"."SkvazhObespNasel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."SkvazhObespNasel" IS 'Нецентрализованное водоснабжение Скважины, колодцы Обеспеченность  привозной водой, % гр.41/гр.9*100';


--
-- Name: COLUMN "SeloForms"."SkvazhKolSelsNasPunkOtkaz"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."SkvazhKolSelsNasPunkOtkaz" IS 'Нецентрализованное водоснабжение Скважины, колодцы Количество сельских населенных пунктов, жители которых отказались от строительства ЦВ, установки КБМ и ПРВ  (наличие протоколов  отказа)';


--
-- Name: COLUMN "SeloForms"."SkvazhKolChelOtkaz"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."SkvazhKolChelOtkaz" IS 'Нецентрализованное водоснабжение Скважины, колодцы Численность населения, жители которых отказались от строительства ЦВ, установки КБМ и ПРВ  (наличие протоколов  отказа)';


--
-- Name: COLUMN "SeloForms"."SkvazhDolyaNaselOtkaz"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."SkvazhDolyaNaselOtkaz" IS 'Нецентрализованное водоснабжение Скважины, колодцы Доля населения, жители которых отказались от строительства ЦВ, установки КБМ и ПРВ  (наличие протоколов  отказа), гр.44/гр.9*100';


--
-- Name: COLUMN "SeloForms"."SkvazhDolyaSelOtkaz"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."SkvazhDolyaSelOtkaz" IS 'Нецентрализованное водоснабжение Скважины, колодцы Доля сел, жители которых отказались от  строительства ЦВ, установки КБМ и ПРВ, %, гр.43/гр.8*100';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedKolSelsNasPunk"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedKolSelsNasPunk" IS 'Централизованное водоотведение Кол-во сельских населенных пунктов (единиц)';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedKolChel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedKolChel" IS 'Централизованное водоотведение Численность населения, проживающего в данных сельских населенных пунктах (человек)';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedKolAbonent"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedKolAbonent" IS 'Централизованное водоотведение Кол-во абонентов, проживающих в данных сельских населенных пунктах (единиц)';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedFizLic"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedFizLic" IS 'Централизованное водоотведение в том числе физических лиц/население (единиц)';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedYriLic"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedYriLic" IS 'Централизованное водоотведение в том числе юридических лиц (единиц)';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedBydzhOrg"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedBydzhOrg" IS 'Централизованное водоотведение в том числе бюджетных организаций (единиц)';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedDostypKolNasPunk"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedDostypKolNasPunk" IS 'Централизованное водоотведение Доступ к централизованному водоотведению по количеству сельских населенных пунктов, в % гр.47/гр.8 *100';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedDostypKolChel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedDostypKolChel" IS 'Централизованное водоотведение Доступ к централизованному водоотведению по численности населения, в % гр.48/гр.9 *100';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedNalich"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedNalich" IS 'Централизованное водоотведение Наличие канализационно- очистных сооружений (единиц)';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedNalichMechan"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedNalichMechan" IS 'Централизованное водоотведение в том числе только с механичес-кой очисткой (еди-ниц)';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedNalichMechanBiolog"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedNalichMechanBiolog" IS 'Централизованное водоотведение в том числе с механической и биологической очист-кой (еди-ниц)';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedProizvod"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedProizvod" IS 'Централизованное водоотведение Производительность канализационно-очистных сооружений (проектная)';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedIznos"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedIznos" IS 'Централизованное водоотведение Износ канализационно- очистных сооружений, в %';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedOhvatKolChel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedOhvatKolChel" IS 'Централизованное водоотведение Числен-ность населе-ния, охваченного действующими канализационно- очистными сооружениями (человек)';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedOhvatNasel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedOhvatNasel" IS 'Централизованное водоотведение Охват населения очисткой сточных вод, в % гр.60/гр.9*100';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedFactPostypStochVod"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedFactPostypStochVod" IS 'Централизованное водоотведение Фактически поступило сточных вод в канализационно-очистные сооружения (тыс.м3)';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedFactPostypStochVod1"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedFactPostypStochVod1" IS 'Централизованное водоотведение В том числе За I квартал (тыс.м3)';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedFactPostypStochVod2"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedFactPostypStochVod2" IS 'Централизованное водоотведение В том числе За II квартал (тыс.м3)';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedFactPostypStochVod3"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedFactPostypStochVod3" IS 'Централизованное водоотведение В том числе За III квартал (тыс.м3)';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedFactPostypStochVod4"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedFactPostypStochVod4" IS 'Централизованное водоотведение В том числе За IV квартал (тыс.м3)';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedObiemStochVod"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedObiemStochVod" IS 'Централизованное водоотведение Объем сточных вод, соответствующей нормативной очистке по собственному лабораторному мониторингу за отчетный период (тыс.м3)';


--
-- Name: COLUMN "SeloForms"."CentrVodOtvedUrovenNorm"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."CentrVodOtvedUrovenNorm" IS 'Централизованное водоотведение Уровень нормативно- очищенной воды, % гр.67/гр.62 * 100';


--
-- Name: COLUMN "SeloForms"."DecentrVodoOtvedKolSelsNasPunk"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."DecentrVodoOtvedKolSelsNasPunk" IS 'Децентрализованное водоотведение Кол-во сельских населенных пунктов (единиц)';


--
-- Name: COLUMN "SeloForms"."DecentrVodoOtvedKolChel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."DecentrVodoOtvedKolChel" IS 'Децентрализованное водоотведение Численность населения, проживающего в данных сельских населенных пунктах (человек)';


--
-- Name: COLUMN "SeloForms"."TarifVodoSnabUsred"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."TarifVodoSnabUsred" IS 'Уровень тарифов водоснабжение усредненный, тенге/м3';


--
-- Name: COLUMN "SeloForms"."TarifVodoSnabFizL"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."TarifVodoSnabFizL" IS 'Уровень тарифов водоснабжение физическим лицам/населению, тенге/м3';


--
-- Name: COLUMN "SeloForms"."TarifVodoSnabYriL"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."TarifVodoSnabYriL" IS 'Уровень тарифов водоснабжение юридическим лицам, тенге/м3';


--
-- Name: COLUMN "SeloForms"."TarifVodoSnabBudzh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."TarifVodoSnabBudzh" IS 'Уровень тарифов водоснабжение бюджетным организациям, тенге/м3';


--
-- Name: COLUMN "SeloForms"."TarifVodoOtvedUsred"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."TarifVodoOtvedUsred" IS 'Уровень тарифов водоотведение усредненный, тенге/м3';


--
-- Name: COLUMN "SeloForms"."TarifVodoOtvedFizL"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."TarifVodoOtvedFizL" IS 'Уровень тарифов водоотведение физическим лицам/населению, тенге/м3';


--
-- Name: COLUMN "SeloForms"."TarifVodoOtvedYriL"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."TarifVodoOtvedYriL" IS 'Уровень тарифов водоотведение юридическим лицам, тенге/м3';


--
-- Name: COLUMN "SeloForms"."TarifVodoOtvedBudzh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."TarifVodoOtvedBudzh" IS 'Уровень тарифов водоотведение бюджетным организациям, тенге/м3';


--
-- Name: COLUMN "SeloForms"."ProtyzhVodoSeteyObsh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."ProtyzhVodoSeteyObsh" IS 'Протяженность водопроводных сетей, км (по состоянию на конец отчетного года) общая, км';


--
-- Name: COLUMN "SeloForms"."ProtyzhVodoSeteyVtomIznos"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."ProtyzhVodoSeteyVtomIznos" IS 'Протяженность водопроводных сетей, км (по состоянию на конец отчетного года) в том числе изношенных, км';


--
-- Name: COLUMN "SeloForms"."ProtyzhVodoSeteyIznos"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."ProtyzhVodoSeteyIznos" IS 'Протяженность водопроводных сетей, км (по состоянию на конец отчетного года) Износ, % гр.80/гр.79';


--
-- Name: COLUMN "SeloForms"."ProtyzhKanalSeteyObsh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."ProtyzhKanalSeteyObsh" IS 'Протяженность канализационных сетей, км (по состоянию на конец отчетного года) общая, км';


--
-- Name: COLUMN "SeloForms"."ProtyzhKanalSeteyVtomIznos"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."ProtyzhKanalSeteyVtomIznos" IS 'Протяженность канализационных сетей, км (по состоянию на конец отчетного года) в том числе изношенных, км';


--
-- Name: COLUMN "SeloForms"."ProtyzhKanalSeteyIznos"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."ProtyzhKanalSeteyIznos" IS 'Протяженность канализационных сетей, км (по состоянию на конец отчетного года) Износ, % гр.83/гр.82';


--
-- Name: COLUMN "SeloForms"."ProtyzhNewSeteyVodoSnab"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."ProtyzhNewSeteyVodoSnab" IS 'Общая протяженность построенных (новых) сетей в отчетном году, км - водоснабжения, км';


--
-- Name: COLUMN "SeloForms"."ProtyzhNewSeteyVodoOtved"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."ProtyzhNewSeteyVodoOtved" IS 'Общая протяженность построенных (новых) сетей в отчетном году, км - водоотведения, км';


--
-- Name: COLUMN "SeloForms"."ProtyzhRekonSeteyVodoSnab"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."ProtyzhRekonSeteyVodoSnab" IS 'Общая протяженность реконструированных (замененных) сетей в отчетном году, км - водоснабжения, км';


--
-- Name: COLUMN "SeloForms"."ProtyzhRekonSeteyVodoOtved"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."ProtyzhRekonSeteyVodoOtved" IS 'Общая протяженность реконструированных (замененных) сетей в отчетном году, км - водоотведения, км';


--
-- Name: COLUMN "SeloForms"."ProtyzhRemontSeteyVodoSnab"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."ProtyzhRemontSeteyVodoSnab" IS 'Общая протяженность отремонтированных (текущий/капитальный ремонт) сетей в отчетном году, км - водоснабжения, км';


--
-- Name: COLUMN "SeloForms"."ProtyzhRemontSeteyVodoOtved"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."SeloForms"."ProtyzhRemontSeteyVodoOtved" IS 'Общая протяженность отремонтированных (текущий/капитальный ремонт) сетей в отчетном году, км - водоотведения, км';


--
-- Name: SettingsValues; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SettingsValues" (
    "Id" integer NOT NULL,
    "Key" text NOT NULL,
    "Value" text NOT NULL
);


ALTER TABLE public."SettingsValues" OWNER TO postgres;

--
-- Name: SettingsValues_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."SettingsValues" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."SettingsValues_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Suppliers" (
    "Id" uuid NOT NULL,
    "Bin" text NOT NULL,
    "FullName" text NOT NULL,
    "KatoId" integer NOT NULL
);


ALTER TABLE public."Suppliers" OWNER TO postgres;

--
-- Name: Tariff_Level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Tariff_Level" (
    "Id" uuid NOT NULL,
    "FormId" uuid NOT NULL,
    "TariffAverage" numeric NOT NULL,
    "TariffIndividual" numeric NOT NULL,
    "TariffLegal" numeric NOT NULL,
    "TariffBudget" numeric NOT NULL,
    "AuthorId" uuid,
    "CreateDate" timestamp with time zone,
    "LastModifiedDate" timestamp with time zone,
    "IsDel" boolean NOT NULL,
    "Description" text NOT NULL
);


ALTER TABLE public."Tariff_Level" OWNER TO postgres;

--
-- Name: COLUMN "Tariff_Level"."TariffAverage"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Tariff_Level"."TariffAverage" IS 'усредненный, тенге/м3';


--
-- Name: COLUMN "Tariff_Level"."TariffIndividual"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Tariff_Level"."TariffIndividual" IS 'физическим лицам/населению, тенге/м3';


--
-- Name: COLUMN "Tariff_Level"."TariffLegal"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Tariff_Level"."TariffLegal" IS 'юридическим лицам, тенге/м3';


--
-- Name: COLUMN "Tariff_Level"."TariffBudget"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Tariff_Level"."TariffBudget" IS 'бюджетным организациям, тенге/м3';


--
-- Name: COLUMN "Tariff_Level"."Description"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Tariff_Level"."Description" IS 'Примечания';


--
-- Name: Universal_Refferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Universal_Refferences" (
    "Id" uuid NOT NULL,
    "ParentId" uuid,
    "Code" text NOT NULL,
    "Type" text NOT NULL,
    "BusinessDecription" text,
    "NameKk" text,
    "NameRu" text,
    "DescriptionKk" text,
    "DescriptionRu" text,
    "IsDel" boolean NOT NULL
);


ALTER TABLE public."Universal_Refferences" OWNER TO postgres;

--
-- Name: COLUMN "Universal_Refferences"."ParentId"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Universal_Refferences"."ParentId" IS 'ключ на ИД (своего типа или стороннего)';


--
-- Name: COLUMN "Universal_Refferences"."Code"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Universal_Refferences"."Code" IS 'Код*';


--
-- Name: COLUMN "Universal_Refferences"."Type"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Universal_Refferences"."Type" IS 'Тип*';


--
-- Name: COLUMN "Universal_Refferences"."BusinessDecription"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Universal_Refferences"."BusinessDecription" IS 'Бизнес описание';


--
-- Name: COLUMN "Universal_Refferences"."NameKk"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Universal_Refferences"."NameKk" IS 'Наименование на каз';


--
-- Name: COLUMN "Universal_Refferences"."NameRu"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Universal_Refferences"."NameRu" IS 'Наименование на рус';


--
-- Name: COLUMN "Universal_Refferences"."DescriptionKk"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Universal_Refferences"."DescriptionKk" IS 'Пояснение на каз';


--
-- Name: COLUMN "Universal_Refferences"."DescriptionRu"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Universal_Refferences"."DescriptionRu" IS 'Пояснение на рус';


--
-- Name: COLUMN "Universal_Refferences"."IsDel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Universal_Refferences"."IsDel" IS 'Удален';


--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


ALTER TABLE public."__EFMigrationsHistory" OWNER TO postgres;

--
-- Data for Name: Account_Roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Account_Roles" ("Id", "RoleId", "AccountId", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Description") FROM stdin;
\.
COPY public."Account_Roles" ("Id", "RoleId", "AccountId", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Description") FROM '$$PATH$$/5062.dat';

--
-- Data for Name: Accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Accounts" ("Id", "Login", "Bin", "PasswordHash", "FullNameRu", "FullNameKk", "StreetName", "BuildingNumber", "KatoCode", "IsActive", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Description") FROM stdin;
\.
COPY public."Accounts" ("Id", "Login", "Bin", "PasswordHash", "FullNameRu", "FullNameKk", "StreetName", "BuildingNumber", "KatoCode", "IsActive", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Description") FROM '$$PATH$$/5033.dat';

--
-- Data for Name: ActionLogs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ActionLogs" ("Id", "AccountId", "FormId", "CreateDate", "LastModifiedDate", "Description", "Error") FROM stdin;
\.
COPY public."ActionLogs" ("Id", "AccountId", "FormId", "CreateDate", "LastModifiedDate", "Description", "Error") FROM '$$PATH$$/5056.dat';

--
-- Data for Name: ApprovedFormItemColumns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ApprovedFormItemColumns" ("Id", "ApprovedFormItemId", "DataType", "Length", "Nullable", "NameKk", "NameRu", "DisplayOrder", "ReportCode") FROM stdin;
\.
COPY public."ApprovedFormItemColumns" ("Id", "ApprovedFormItemId", "DataType", "Length", "Nullable", "NameKk", "NameRu", "DisplayOrder", "ReportCode") FROM '$$PATH$$/5067.dat';

--
-- Data for Name: ApprovedFormItems; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ApprovedFormItems" ("Id", "ApprovedFormId", "ServiceId", "Title", "DisplayOrder", "IsVillage", "IsDel") FROM stdin;
\.
COPY public."ApprovedFormItems" ("Id", "ApprovedFormId", "ServiceId", "Title", "DisplayOrder", "IsVillage", "IsDel") FROM '$$PATH$$/5057.dat';

--
-- Data for Name: ApprovedForms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ApprovedForms" ("Id", "Description", "ApprovalDate", "CompletionDate", "IsDel", "DeletedById") FROM stdin;
\.
COPY public."ApprovedForms" ("Id", "Description", "ApprovalDate", "CompletionDate", "IsDel", "DeletedById") FROM '$$PATH$$/5034.dat';

--
-- Data for Name: Business_Dictionary; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Business_Dictionary" ("Id", "ParentId", "Code", "Type", "BusinessDecription", "NameKk", "NameRu", "DescriptionKk", "DescriptionRu", "IsDel") FROM stdin;
\.
COPY public."Business_Dictionary" ("Id", "ParentId", "Code", "Type", "BusinessDecription", "NameKk", "NameRu", "DescriptionKk", "DescriptionRu", "IsDel") FROM '$$PATH$$/5035.dat';

--
-- Data for Name: CityDocuments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CityDocuments" ("Id", "CityFormId", "KodNaselPunk", "KodOblast", "KodRaiona", "Login", "Year") FROM stdin;
\.
COPY public."CityDocuments" ("Id", "CityFormId", "KodNaselPunk", "KodOblast", "KodRaiona", "Login", "Year") FROM '$$PATH$$/5058.dat';

--
-- Data for Name: CityForms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CityForms" ("Id", "TotalCountCityOblast", "TotalCountDomHoz", "TotalCountChel", "ObslPredpId") FROM stdin;
\.
COPY public."CityForms" ("Id", "TotalCountCityOblast", "TotalCountDomHoz", "TotalCountChel", "ObslPredpId") FROM '$$PATH$$/5036.dat';

--
-- Data for Name: CityNetworkLengths; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CityNetworkLengths" ("Id", "IdForm", "VodoProvodLengthTotal", "VodoProvodLengthIznos", "VodoProvodIznosPercent", "KanalizLengthTotal", "KanalizLengthIznos", "KanalizIznosPercent", "ObshNewSetiVodo", "ObshNewSetiKanaliz", "ObshZamenSetiVodo", "ObshZamenSetiKanaliz", "ObshRemontSetiVodo", "ObshRemontSetiKanaliz") FROM stdin;
\.
COPY public."CityNetworkLengths" ("Id", "IdForm", "VodoProvodLengthTotal", "VodoProvodLengthIznos", "VodoProvodIznosPercent", "KanalizLengthTotal", "KanalizLengthIznos", "KanalizIznosPercent", "ObshNewSetiVodo", "ObshNewSetiKanaliz", "ObshZamenSetiVodo", "ObshZamenSetiKanaliz", "ObshRemontSetiVodo", "ObshRemontSetiKanaliz") FROM '$$PATH$$/5037.dat';

--
-- Data for Name: CityTarifs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CityTarifs" ("Id", "IdForm", "VodoSnabUsrednen", "VodoSnabFizLic", "VodoSnabYriLic", "VodoSnabBydzhOrg", "VodoOtvedUsred", "VodoOtvedFizLic", "VodoOtvedYriLic", "VodoOtvedBydzhOrg") FROM stdin;
\.
COPY public."CityTarifs" ("Id", "IdForm", "VodoSnabUsrednen", "VodoSnabFizLic", "VodoSnabYriLic", "VodoSnabBydzhOrg", "VodoOtvedUsred", "VodoOtvedFizLic", "VodoOtvedYriLic", "VodoOtvedBydzhOrg") FROM '$$PATH$$/5038.dat';

--
-- Data for Name: CityWaterDisposals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CityWaterDisposals" ("Id", "IdForm", "KolAbonent", "KolFizLic", "KolYriLic", "KolBydzhetOrg", "KolChelOhvatCentrVodo", "DostypCentrVodo", "KolichKanaliz", "KolichKanalizMechan", "KolichKanalizMechanBiolog", "ProizvodKanaliz", "IznosKanaliz", "KolChelKanaliz", "OhvatChelKanaliz", "FactPostypKanaliz", "FactPostypKanaliz1kv", "FactPostypKanaliz2kv", "FactPostypKanaliz3kv", "FactPostypKanaliz4kv", "ObiemKanalizNormOchist", "UrovenNormOchishVody", "AutoProccesSetKanaliz", "AutoProccesKanalizNasos", "AutoProccesKanalizSooruzh") FROM stdin;
\.
COPY public."CityWaterDisposals" ("Id", "IdForm", "KolAbonent", "KolFizLic", "KolYriLic", "KolBydzhetOrg", "KolChelOhvatCentrVodo", "DostypCentrVodo", "KolichKanaliz", "KolichKanalizMechan", "KolichKanalizMechanBiolog", "ProizvodKanaliz", "IznosKanaliz", "KolChelKanaliz", "OhvatChelKanaliz", "FactPostypKanaliz", "FactPostypKanaliz1kv", "FactPostypKanaliz2kv", "FactPostypKanaliz3kv", "FactPostypKanaliz4kv", "ObiemKanalizNormOchist", "UrovenNormOchishVody", "AutoProccesSetKanaliz", "AutoProccesKanalizNasos", "AutoProccesKanalizSooruzh") FROM '$$PATH$$/5039.dat';

--
-- Data for Name: CityWaterSupplies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CityWaterSupplies" ("Id", "IdForm", "KolichAbonent", "KolFizLic", "KolYriLic", "KolBydzhOrg", "KolChelDostyp", "ObespechCentrlVodo", "IndivUchetVodyVsego", "IndivUchetVodyDistance", "IndivUchetVodyPercent", "ObshePodlezhashKolZdan", "ObsheUstanKolZdan", "ObsheUstanPriborKol", "ObsheUstanDistanceKol", "ObsheOhvatPercent", "AutoProccesVodoZabor", "AutoProccesVodoPodgot", "AutoProccesNasosStanc", "AutoProccesSetVodosnab") FROM stdin;
\.
COPY public."CityWaterSupplies" ("Id", "IdForm", "KolichAbonent", "KolFizLic", "KolYriLic", "KolBydzhOrg", "KolChelDostyp", "ObespechCentrlVodo", "IndivUchetVodyVsego", "IndivUchetVodyDistance", "IndivUchetVodyPercent", "ObshePodlezhashKolZdan", "ObsheUstanKolZdan", "ObsheUstanPriborKol", "ObsheUstanDistanceKol", "ObsheOhvatPercent", "AutoProccesVodoZabor", "AutoProccesVodoPodgot", "AutoProccesNasosStanc", "AutoProccesSetVodosnab") FROM '$$PATH$$/5040.dat';

--
-- Data for Name: ColumnLayouts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ColumnLayouts" ("Id", "ApprovedFormItemColumnId", "Height", "Width", "Position") FROM stdin;
\.
COPY public."ColumnLayouts" ("Id", "ApprovedFormItemColumnId", "Height", "Width", "Position") FROM '$$PATH$$/5074.dat';

--
-- Data for Name: Consumers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Consumers" ("Id", "SupplierId", "Ref_KatoId") FROM stdin;
\.
COPY public."Consumers" ("Id", "SupplierId", "Ref_KatoId") FROM '$$PATH$$/5070.dat';

--
-- Data for Name: Data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Data" ("Id", "ApprovedFormId", "ApprovedFormItemId", "ApproverFormColumnId", "ReportFormId", "ValueType", "ValueJson", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Description") FROM stdin;
\.
COPY public."Data" ("Id", "ApprovedFormId", "ApprovedFormItemId", "ApproverFormColumnId", "ReportFormId", "ValueType", "ValueJson", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Description") FROM '$$PATH$$/5041.dat';

--
-- Data for Name: Pipelines; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Pipelines" ("Id", "FormId", "TotalPipelineLength", "WornPipelineLength", "TotalSewerNetworkLength", "WornSewerNetworkLength", "NewWaterSupplyNetworkLength", "NewWastewaterNetworkLength", "ReconstructedNetworkLength", "ReconstructedWastewaterNetworkLength", "RepairedWaterSupplyNetworkLength", "RepairedWastewaterNetworkLength", "TotalPopulation", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Description") FROM stdin;
\.
COPY public."Pipelines" ("Id", "FormId", "TotalPipelineLength", "WornPipelineLength", "TotalSewerNetworkLength", "WornSewerNetworkLength", "NewWaterSupplyNetworkLength", "NewWastewaterNetworkLength", "ReconstructedNetworkLength", "ReconstructedWastewaterNetworkLength", "RepairedWaterSupplyNetworkLength", "RepairedWastewaterNetworkLength", "TotalPopulation", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Description") FROM '$$PATH$$/5071.dat';

--
-- Data for Name: Ref_Access; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Ref_Access" ("Id", "NameRu", "CodeAccessName", "TypeAccessName", "ActionName", "NameKk", "IsDel", "Description") FROM stdin;
\.
COPY public."Ref_Access" ("Id", "NameRu", "CodeAccessName", "TypeAccessName", "ActionName", "NameKk", "IsDel", "Description") FROM '$$PATH$$/5043.dat';

--
-- Data for Name: Ref_Buildings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Ref_Buildings" ("Id", "RefStreetId", "Building", "NameRu", "NameKk", "IsDel", "Description") FROM stdin;
\.
COPY public."Ref_Buildings" ("Id", "RefStreetId", "Building", "NameRu", "NameKk", "IsDel", "Description") FROM '$$PATH$$/5069.dat';

--
-- Data for Name: Ref_Katos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Ref_Katos" ("Id", "ParentId", "Code", "Latitude", "Longitude", "UserId", "IsReportable", "KatoLevel", "ParentRaion", "ParentObl", "NameRu", "NameKk", "IsDel", "Description") FROM stdin;
\.
COPY public."Ref_Katos" ("Id", "ParentId", "Code", "Latitude", "Longitude", "UserId", "IsReportable", "KatoLevel", "ParentRaion", "ParentObl", "NameRu", "NameKk", "IsDel", "Description") FROM '$$PATH$$/5045.dat';

--
-- Data for Name: Ref_Role_Access; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Ref_Role_Access" ("Id", "RoleId", "AccessId", "NameRu", "NameKk", "IsDel", "Description") FROM stdin;
\.
COPY public."Ref_Role_Access" ("Id", "RoleId", "AccessId", "NameRu", "NameKk", "IsDel", "Description") FROM '$$PATH$$/5064.dat';

--
-- Data for Name: Ref_Roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Ref_Roles" ("Id", "Code", "TypeName", "NameRu", "NameKk", "IsDel", "Description") FROM stdin;
\.
COPY public."Ref_Roles" ("Id", "Code", "TypeName", "NameRu", "NameKk", "IsDel", "Description") FROM '$$PATH$$/5047.dat';

--
-- Data for Name: Ref_Statuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Ref_Statuses" ("Id", "NameRu", "NameKk", "IsDel", "Description") FROM stdin;
\.
COPY public."Ref_Statuses" ("Id", "NameRu", "NameKk", "IsDel", "Description") FROM '$$PATH$$/5049.dat';

--
-- Data for Name: Ref_Streets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Ref_Streets" ("Id", "RefKatoId", "NameRu", "NameKk", "IsDel", "Description") FROM stdin;
\.
COPY public."Ref_Streets" ("Id", "RefKatoId", "NameRu", "NameKk", "IsDel", "Description") FROM '$$PATH$$/5060.dat';

--
-- Data for Name: ReportSuppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ReportSuppliers" ("Id", "Report_FormId", "SupplierId", "ServiceId", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Description") FROM stdin;
\.
COPY public."ReportSuppliers" ("Id", "Report_FormId", "SupplierId", "ServiceId", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Description") FROM '$$PATH$$/5072.dat';

--
-- Data for Name: Report_Forms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Report_Forms" ("Id", "ApprovedFormId", "RefKatoId", "ReportYearId", "ReportMonthId", "RefStatusId", "HasStreets", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Description") FROM stdin;
\.
COPY public."Report_Forms" ("Id", "ApprovedFormId", "RefKatoId", "ReportYearId", "ReportMonthId", "RefStatusId", "HasStreets", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Description") FROM '$$PATH$$/5065.dat';

--
-- Data for Name: ResponseCodes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ResponseCodes" ("Id", "NameCode", "DescriptionCode", "BeginDate", "EndDate") FROM stdin;
\.
COPY public."ResponseCodes" ("Id", "NameCode", "DescriptionCode", "BeginDate", "EndDate") FROM '$$PATH$$/5051.dat';

--
-- Data for Name: SeloDocuments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SeloDocuments" ("Id", "SeloFormId", "KodNaselPunk", "KodOblast", "KodRaiona", "Login", "Year") FROM stdin;
\.
COPY public."SeloDocuments" ("Id", "SeloFormId", "KodNaselPunk", "KodOblast", "KodRaiona", "Login", "Year") FROM '$$PATH$$/5066.dat';

--
-- Data for Name: SeloForms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SeloForms" ("Id", "StatusOpor", "StatusSput", "StatusProch", "StatusPrigran", "ObshKolSelNasPun", "ObshKolChelNasPun", "ObshKolDomHoz", "YearSystVodoSnab", "ObslPredpId", "SobstId", "DosVodoSnabKolPunk", "DosVodoSnabKolChel", "DosVodoSnabPercent", "CentrVodoSnabKolNasPun", "CentrVodoSnabKolChel", "CentrVodoSnabObesKolNasPunk", "CentrVodoSnabObesKolChel", "CentrVodoSnabKolAbon", "CentrVodoSnabFizLic", "CentrVodoSnabYriLic", "CentrVodoSnabBudzhOrg", "CentrVodoIndivPriborUchVodyVsego", "CentrVodoIndivPriborUchVodyASYE", "CentrVodoIndivPriborUchVodyOhvat", "NeCtentrVodoKolSelsNasPunk", "KbmKolSelsNasPunk", "KbmKolChel", "KbmObespNasel", "PrvKolSelsNasPunk", "PrvKolChel", "PrvObespNasel", "PrivVodaKolSelsNasPunk", "PrivVodaKolChel", "PrivVodaObespNasel", "SkvazhKolSelsNasPunk", "SkvazhKolChel", "SkvazhObespNasel", "SkvazhKolSelsNasPunkOtkaz", "SkvazhKolChelOtkaz", "SkvazhDolyaNaselOtkaz", "SkvazhDolyaSelOtkaz", "CentrVodOtvedKolSelsNasPunk", "CentrVodOtvedKolChel", "CentrVodOtvedKolAbonent", "CentrVodOtvedFizLic", "CentrVodOtvedYriLic", "CentrVodOtvedBydzhOrg", "CentrVodOtvedDostypKolNasPunk", "CentrVodOtvedDostypKolChel", "CentrVodOtvedNalich", "CentrVodOtvedNalichMechan", "CentrVodOtvedNalichMechanBiolog", "CentrVodOtvedProizvod", "CentrVodOtvedIznos", "CentrVodOtvedOhvatKolChel", "CentrVodOtvedOhvatNasel", "CentrVodOtvedFactPostypStochVod", "CentrVodOtvedFactPostypStochVod1", "CentrVodOtvedFactPostypStochVod2", "CentrVodOtvedFactPostypStochVod3", "CentrVodOtvedFactPostypStochVod4", "CentrVodOtvedObiemStochVod", "CentrVodOtvedUrovenNorm", "DecentrVodoOtvedKolSelsNasPunk", "DecentrVodoOtvedKolChel", "TarifVodoSnabUsred", "TarifVodoSnabFizL", "TarifVodoSnabYriL", "TarifVodoSnabBudzh", "TarifVodoOtvedUsred", "TarifVodoOtvedFizL", "TarifVodoOtvedYriL", "TarifVodoOtvedBudzh", "ProtyzhVodoSeteyObsh", "ProtyzhVodoSeteyVtomIznos", "ProtyzhVodoSeteyIznos", "ProtyzhKanalSeteyObsh", "ProtyzhKanalSeteyVtomIznos", "ProtyzhKanalSeteyIznos", "ProtyzhNewSeteyVodoSnab", "ProtyzhNewSeteyVodoOtved", "ProtyzhRekonSeteyVodoSnab", "ProtyzhRekonSeteyVodoOtved", "ProtyzhRemontSeteyVodoSnab", "ProtyzhRemontSeteyVodoOtved") FROM stdin;
\.
COPY public."SeloForms" ("Id", "StatusOpor", "StatusSput", "StatusProch", "StatusPrigran", "ObshKolSelNasPun", "ObshKolChelNasPun", "ObshKolDomHoz", "YearSystVodoSnab", "ObslPredpId", "SobstId", "DosVodoSnabKolPunk", "DosVodoSnabKolChel", "DosVodoSnabPercent", "CentrVodoSnabKolNasPun", "CentrVodoSnabKolChel", "CentrVodoSnabObesKolNasPunk", "CentrVodoSnabObesKolChel", "CentrVodoSnabKolAbon", "CentrVodoSnabFizLic", "CentrVodoSnabYriLic", "CentrVodoSnabBudzhOrg", "CentrVodoIndivPriborUchVodyVsego", "CentrVodoIndivPriborUchVodyASYE", "CentrVodoIndivPriborUchVodyOhvat", "NeCtentrVodoKolSelsNasPunk", "KbmKolSelsNasPunk", "KbmKolChel", "KbmObespNasel", "PrvKolSelsNasPunk", "PrvKolChel", "PrvObespNasel", "PrivVodaKolSelsNasPunk", "PrivVodaKolChel", "PrivVodaObespNasel", "SkvazhKolSelsNasPunk", "SkvazhKolChel", "SkvazhObespNasel", "SkvazhKolSelsNasPunkOtkaz", "SkvazhKolChelOtkaz", "SkvazhDolyaNaselOtkaz", "SkvazhDolyaSelOtkaz", "CentrVodOtvedKolSelsNasPunk", "CentrVodOtvedKolChel", "CentrVodOtvedKolAbonent", "CentrVodOtvedFizLic", "CentrVodOtvedYriLic", "CentrVodOtvedBydzhOrg", "CentrVodOtvedDostypKolNasPunk", "CentrVodOtvedDostypKolChel", "CentrVodOtvedNalich", "CentrVodOtvedNalichMechan", "CentrVodOtvedNalichMechanBiolog", "CentrVodOtvedProizvod", "CentrVodOtvedIznos", "CentrVodOtvedOhvatKolChel", "CentrVodOtvedOhvatNasel", "CentrVodOtvedFactPostypStochVod", "CentrVodOtvedFactPostypStochVod1", "CentrVodOtvedFactPostypStochVod2", "CentrVodOtvedFactPostypStochVod3", "CentrVodOtvedFactPostypStochVod4", "CentrVodOtvedObiemStochVod", "CentrVodOtvedUrovenNorm", "DecentrVodoOtvedKolSelsNasPunk", "DecentrVodoOtvedKolChel", "TarifVodoSnabUsred", "TarifVodoSnabFizL", "TarifVodoSnabYriL", "TarifVodoSnabBudzh", "TarifVodoOtvedUsred", "TarifVodoOtvedFizL", "TarifVodoOtvedYriL", "TarifVodoOtvedBudzh", "ProtyzhVodoSeteyObsh", "ProtyzhVodoSeteyVtomIznos", "ProtyzhVodoSeteyIznos", "ProtyzhKanalSeteyObsh", "ProtyzhKanalSeteyVtomIznos", "ProtyzhKanalSeteyIznos", "ProtyzhNewSeteyVodoSnab", "ProtyzhNewSeteyVodoOtved", "ProtyzhRekonSeteyVodoSnab", "ProtyzhRekonSeteyVodoOtved", "ProtyzhRemontSeteyVodoSnab", "ProtyzhRemontSeteyVodoOtved") FROM '$$PATH$$/5052.dat';

--
-- Data for Name: SettingsValues; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SettingsValues" ("Id", "Key", "Value") FROM stdin;
\.
COPY public."SettingsValues" ("Id", "Key", "Value") FROM '$$PATH$$/5054.dat';

--
-- Data for Name: Suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Suppliers" ("Id", "Bin", "FullName", "KatoId") FROM stdin;
\.
COPY public."Suppliers" ("Id", "Bin", "FullName", "KatoId") FROM '$$PATH$$/5061.dat';

--
-- Data for Name: Tariff_Level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Tariff_Level" ("Id", "FormId", "TariffAverage", "TariffIndividual", "TariffLegal", "TariffBudget", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Description") FROM stdin;
\.
COPY public."Tariff_Level" ("Id", "FormId", "TariffAverage", "TariffIndividual", "TariffLegal", "TariffBudget", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Description") FROM '$$PATH$$/5073.dat';

--
-- Data for Name: Universal_Refferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Universal_Refferences" ("Id", "ParentId", "Code", "Type", "BusinessDecription", "NameKk", "NameRu", "DescriptionKk", "DescriptionRu", "IsDel") FROM stdin;
\.
COPY public."Universal_Refferences" ("Id", "ParentId", "Code", "Type", "BusinessDecription", "NameKk", "NameRu", "DescriptionKk", "DescriptionRu", "IsDel") FROM '$$PATH$$/5055.dat';

--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
\.
COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM '$$PATH$$/5032.dat';

--
-- Name: Ref_Access_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Ref_Access_Id_seq"', 16, true);


--
-- Name: Ref_Buildings_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Ref_Buildings_Id_seq"', 1, false);


--
-- Name: Ref_Katos_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Ref_Katos_Id_seq"', 1, false);


--
-- Name: Ref_Role_Access_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Ref_Role_Access_Id_seq"', 15, true);


--
-- Name: Ref_Roles_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Ref_Roles_Id_seq"', 5, true);


--
-- Name: Ref_Statuses_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Ref_Statuses_Id_seq"', 1, false);


--
-- Name: Ref_Streets_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Ref_Streets_Id_seq"', 1, false);


--
-- Name: ResponseCodes_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ResponseCodes_Id_seq"', 3, true);


--
-- Name: SettingsValues_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SettingsValues_Id_seq"', 2, true);


--
-- Name: Account_Roles PK_Account_Roles; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Account_Roles"
    ADD CONSTRAINT "PK_Account_Roles" PRIMARY KEY ("Id");


--
-- Name: Accounts PK_Accounts; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Accounts"
    ADD CONSTRAINT "PK_Accounts" PRIMARY KEY ("Id");


--
-- Name: ActionLogs PK_ActionLogs; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ActionLogs"
    ADD CONSTRAINT "PK_ActionLogs" PRIMARY KEY ("Id");


--
-- Name: ApprovedFormItemColumns PK_ApprovedFormItemColumns; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ApprovedFormItemColumns"
    ADD CONSTRAINT "PK_ApprovedFormItemColumns" PRIMARY KEY ("Id");


--
-- Name: ApprovedFormItems PK_ApprovedFormItems; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ApprovedFormItems"
    ADD CONSTRAINT "PK_ApprovedFormItems" PRIMARY KEY ("Id");


--
-- Name: ApprovedForms PK_ApprovedForms; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ApprovedForms"
    ADD CONSTRAINT "PK_ApprovedForms" PRIMARY KEY ("Id");


--
-- Name: Business_Dictionary PK_Business_Dictionary; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Business_Dictionary"
    ADD CONSTRAINT "PK_Business_Dictionary" PRIMARY KEY ("Id");


--
-- Name: CityDocuments PK_CityDocuments; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CityDocuments"
    ADD CONSTRAINT "PK_CityDocuments" PRIMARY KEY ("Id");


--
-- Name: CityForms PK_CityForms; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CityForms"
    ADD CONSTRAINT "PK_CityForms" PRIMARY KEY ("Id");


--
-- Name: CityNetworkLengths PK_CityNetworkLengths; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CityNetworkLengths"
    ADD CONSTRAINT "PK_CityNetworkLengths" PRIMARY KEY ("Id");


--
-- Name: CityTarifs PK_CityTarifs; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CityTarifs"
    ADD CONSTRAINT "PK_CityTarifs" PRIMARY KEY ("Id");


--
-- Name: CityWaterDisposals PK_CityWaterDisposals; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CityWaterDisposals"
    ADD CONSTRAINT "PK_CityWaterDisposals" PRIMARY KEY ("Id");


--
-- Name: CityWaterSupplies PK_CityWaterSupplies; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CityWaterSupplies"
    ADD CONSTRAINT "PK_CityWaterSupplies" PRIMARY KEY ("Id");


--
-- Name: ColumnLayouts PK_ColumnLayouts; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ColumnLayouts"
    ADD CONSTRAINT "PK_ColumnLayouts" PRIMARY KEY ("Id");


--
-- Name: Consumers PK_Consumers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Consumers"
    ADD CONSTRAINT "PK_Consumers" PRIMARY KEY ("Id");


--
-- Name: Data PK_Data; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Data"
    ADD CONSTRAINT "PK_Data" PRIMARY KEY ("Id");


--
-- Name: Pipelines PK_Pipelines; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pipelines"
    ADD CONSTRAINT "PK_Pipelines" PRIMARY KEY ("Id");


--
-- Name: Ref_Access PK_Ref_Access; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ref_Access"
    ADD CONSTRAINT "PK_Ref_Access" PRIMARY KEY ("Id");


--
-- Name: Ref_Buildings PK_Ref_Buildings; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ref_Buildings"
    ADD CONSTRAINT "PK_Ref_Buildings" PRIMARY KEY ("Id");


--
-- Name: Ref_Katos PK_Ref_Katos; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ref_Katos"
    ADD CONSTRAINT "PK_Ref_Katos" PRIMARY KEY ("Id");


--
-- Name: Ref_Role_Access PK_Ref_Role_Access; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ref_Role_Access"
    ADD CONSTRAINT "PK_Ref_Role_Access" PRIMARY KEY ("Id");


--
-- Name: Ref_Roles PK_Ref_Roles; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ref_Roles"
    ADD CONSTRAINT "PK_Ref_Roles" PRIMARY KEY ("Id");


--
-- Name: Ref_Statuses PK_Ref_Statuses; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ref_Statuses"
    ADD CONSTRAINT "PK_Ref_Statuses" PRIMARY KEY ("Id");


--
-- Name: Ref_Streets PK_Ref_Streets; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ref_Streets"
    ADD CONSTRAINT "PK_Ref_Streets" PRIMARY KEY ("Id");


--
-- Name: ReportSuppliers PK_ReportSuppliers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ReportSuppliers"
    ADD CONSTRAINT "PK_ReportSuppliers" PRIMARY KEY ("Id");


--
-- Name: Report_Forms PK_Report_Forms; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report_Forms"
    ADD CONSTRAINT "PK_Report_Forms" PRIMARY KEY ("Id");


--
-- Name: ResponseCodes PK_ResponseCodes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResponseCodes"
    ADD CONSTRAINT "PK_ResponseCodes" PRIMARY KEY ("Id");


--
-- Name: SeloDocuments PK_SeloDocuments; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SeloDocuments"
    ADD CONSTRAINT "PK_SeloDocuments" PRIMARY KEY ("Id");


--
-- Name: SeloForms PK_SeloForms; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SeloForms"
    ADD CONSTRAINT "PK_SeloForms" PRIMARY KEY ("Id");


--
-- Name: SettingsValues PK_SettingsValues; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SettingsValues"
    ADD CONSTRAINT "PK_SettingsValues" PRIMARY KEY ("Id");


--
-- Name: Suppliers PK_Suppliers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Suppliers"
    ADD CONSTRAINT "PK_Suppliers" PRIMARY KEY ("Id");


--
-- Name: Tariff_Level PK_Tariff_Level; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Tariff_Level"
    ADD CONSTRAINT "PK_Tariff_Level" PRIMARY KEY ("Id");


--
-- Name: Universal_Refferences PK_Universal_Refferences; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Universal_Refferences"
    ADD CONSTRAINT "PK_Universal_Refferences" PRIMARY KEY ("Id");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: IX_Account_Roles_AccountId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Account_Roles_AccountId" ON public."Account_Roles" USING btree ("AccountId");


--
-- Name: IX_Account_Roles_RoleId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Account_Roles_RoleId" ON public."Account_Roles" USING btree ("RoleId");


--
-- Name: IX_ActionLogs_AccountId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_ActionLogs_AccountId" ON public."ActionLogs" USING btree ("AccountId");


--
-- Name: IX_ApprovedFormItemColumns_ApprovedFormItemId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_ApprovedFormItemColumns_ApprovedFormItemId" ON public."ApprovedFormItemColumns" USING btree ("ApprovedFormItemId");


--
-- Name: IX_ApprovedFormItems_ApprovedFormId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_ApprovedFormItems_ApprovedFormId" ON public."ApprovedFormItems" USING btree ("ApprovedFormId");


--
-- Name: IX_CityDocuments_CityFormId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_CityDocuments_CityFormId" ON public."CityDocuments" USING btree ("CityFormId");


--
-- Name: IX_ColumnLayouts_ApprovedFormItemColumnId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_ColumnLayouts_ApprovedFormItemColumnId" ON public."ColumnLayouts" USING btree ("ApprovedFormItemColumnId");


--
-- Name: IX_Consumers_Ref_KatoId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Consumers_Ref_KatoId" ON public."Consumers" USING btree ("Ref_KatoId");


--
-- Name: IX_Consumers_SupplierId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Consumers_SupplierId" ON public."Consumers" USING btree ("SupplierId");


--
-- Name: IX_Pipelines_FormId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Pipelines_FormId" ON public."Pipelines" USING btree ("FormId");


--
-- Name: IX_Ref_Buildings_RefStreetId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Ref_Buildings_RefStreetId" ON public."Ref_Buildings" USING btree ("RefStreetId");


--
-- Name: IX_Ref_Role_Access_AccessId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Ref_Role_Access_AccessId" ON public."Ref_Role_Access" USING btree ("AccessId");


--
-- Name: IX_Ref_Role_Access_RoleId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Ref_Role_Access_RoleId" ON public."Ref_Role_Access" USING btree ("RoleId");


--
-- Name: IX_Ref_Streets_RefKatoId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Ref_Streets_RefKatoId" ON public."Ref_Streets" USING btree ("RefKatoId");


--
-- Name: IX_ReportSuppliers_Report_FormId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_ReportSuppliers_Report_FormId" ON public."ReportSuppliers" USING btree ("Report_FormId");


--
-- Name: IX_ReportSuppliers_SupplierId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_ReportSuppliers_SupplierId" ON public."ReportSuppliers" USING btree ("SupplierId");


--
-- Name: IX_Report_Forms_ApprovedFormId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Report_Forms_ApprovedFormId" ON public."Report_Forms" USING btree ("ApprovedFormId");


--
-- Name: IX_Report_Forms_RefKatoId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Report_Forms_RefKatoId" ON public."Report_Forms" USING btree ("RefKatoId");


--
-- Name: IX_Report_Forms_RefStatusId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Report_Forms_RefStatusId" ON public."Report_Forms" USING btree ("RefStatusId");


--
-- Name: IX_SeloDocuments_SeloFormId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_SeloDocuments_SeloFormId" ON public."SeloDocuments" USING btree ("SeloFormId");


--
-- Name: IX_Suppliers_KatoId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Suppliers_KatoId" ON public."Suppliers" USING btree ("KatoId");


--
-- Name: IX_Tariff_Level_FormId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Tariff_Level_FormId" ON public."Tariff_Level" USING btree ("FormId");


--
-- Name: Account_Roles FK_Account_Roles_Accounts_AccountId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Account_Roles"
    ADD CONSTRAINT "FK_Account_Roles_Accounts_AccountId" FOREIGN KEY ("AccountId") REFERENCES public."Accounts"("Id") ON DELETE CASCADE;


--
-- Name: Account_Roles FK_Account_Roles_Ref_Roles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Account_Roles"
    ADD CONSTRAINT "FK_Account_Roles_Ref_Roles_RoleId" FOREIGN KEY ("RoleId") REFERENCES public."Ref_Roles"("Id") ON DELETE CASCADE;


--
-- Name: ActionLogs FK_ActionLogs_Accounts_AccountId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ActionLogs"
    ADD CONSTRAINT "FK_ActionLogs_Accounts_AccountId" FOREIGN KEY ("AccountId") REFERENCES public."Accounts"("Id") ON DELETE CASCADE;


--
-- Name: ApprovedFormItemColumns FK_ApprovedFormItemColumns_ApprovedFormItems_ApprovedFormItemId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ApprovedFormItemColumns"
    ADD CONSTRAINT "FK_ApprovedFormItemColumns_ApprovedFormItems_ApprovedFormItemId" FOREIGN KEY ("ApprovedFormItemId") REFERENCES public."ApprovedFormItems"("Id") ON DELETE CASCADE;


--
-- Name: ApprovedFormItems FK_ApprovedFormItems_ApprovedForms_ApprovedFormId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ApprovedFormItems"
    ADD CONSTRAINT "FK_ApprovedFormItems_ApprovedForms_ApprovedFormId" FOREIGN KEY ("ApprovedFormId") REFERENCES public."ApprovedForms"("Id") ON DELETE CASCADE;


--
-- Name: CityDocuments FK_CityDocuments_CityForms_CityFormId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CityDocuments"
    ADD CONSTRAINT "FK_CityDocuments_CityForms_CityFormId" FOREIGN KEY ("CityFormId") REFERENCES public."CityForms"("Id");


--
-- Name: ColumnLayouts FK_ColumnLayouts_ApprovedFormItemColumns_ApprovedFormItemColum~; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ColumnLayouts"
    ADD CONSTRAINT "FK_ColumnLayouts_ApprovedFormItemColumns_ApprovedFormItemColum~" FOREIGN KEY ("ApprovedFormItemColumnId") REFERENCES public."ApprovedFormItemColumns"("Id") ON DELETE CASCADE;


--
-- Name: Consumers FK_Consumers_Ref_Katos_Ref_KatoId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Consumers"
    ADD CONSTRAINT "FK_Consumers_Ref_Katos_Ref_KatoId" FOREIGN KEY ("Ref_KatoId") REFERENCES public."Ref_Katos"("Id");


--
-- Name: Consumers FK_Consumers_Suppliers_SupplierId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Consumers"
    ADD CONSTRAINT "FK_Consumers_Suppliers_SupplierId" FOREIGN KEY ("SupplierId") REFERENCES public."Suppliers"("Id") ON DELETE CASCADE;


--
-- Name: Pipelines FK_Pipelines_Report_Forms_FormId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pipelines"
    ADD CONSTRAINT "FK_Pipelines_Report_Forms_FormId" FOREIGN KEY ("FormId") REFERENCES public."Report_Forms"("Id") ON DELETE CASCADE;


--
-- Name: Ref_Buildings FK_Ref_Buildings_Ref_Streets_RefStreetId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ref_Buildings"
    ADD CONSTRAINT "FK_Ref_Buildings_Ref_Streets_RefStreetId" FOREIGN KEY ("RefStreetId") REFERENCES public."Ref_Streets"("Id") ON DELETE CASCADE;


--
-- Name: Ref_Role_Access FK_Ref_Role_Access_Ref_Access_AccessId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ref_Role_Access"
    ADD CONSTRAINT "FK_Ref_Role_Access_Ref_Access_AccessId" FOREIGN KEY ("AccessId") REFERENCES public."Ref_Access"("Id") ON DELETE CASCADE;


--
-- Name: Ref_Role_Access FK_Ref_Role_Access_Ref_Roles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ref_Role_Access"
    ADD CONSTRAINT "FK_Ref_Role_Access_Ref_Roles_RoleId" FOREIGN KEY ("RoleId") REFERENCES public."Ref_Roles"("Id") ON DELETE CASCADE;


--
-- Name: Ref_Streets FK_Ref_Streets_Ref_Katos_RefKatoId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ref_Streets"
    ADD CONSTRAINT "FK_Ref_Streets_Ref_Katos_RefKatoId" FOREIGN KEY ("RefKatoId") REFERENCES public."Ref_Katos"("Id") ON DELETE CASCADE;


--
-- Name: ReportSuppliers FK_ReportSuppliers_Report_Forms_Report_FormId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ReportSuppliers"
    ADD CONSTRAINT "FK_ReportSuppliers_Report_Forms_Report_FormId" FOREIGN KEY ("Report_FormId") REFERENCES public."Report_Forms"("Id") ON DELETE CASCADE;


--
-- Name: ReportSuppliers FK_ReportSuppliers_Suppliers_SupplierId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ReportSuppliers"
    ADD CONSTRAINT "FK_ReportSuppliers_Suppliers_SupplierId" FOREIGN KEY ("SupplierId") REFERENCES public."Suppliers"("Id") ON DELETE CASCADE;


--
-- Name: Report_Forms FK_Report_Forms_ApprovedForms_ApprovedFormId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report_Forms"
    ADD CONSTRAINT "FK_Report_Forms_ApprovedForms_ApprovedFormId" FOREIGN KEY ("ApprovedFormId") REFERENCES public."ApprovedForms"("Id") ON DELETE CASCADE;


--
-- Name: Report_Forms FK_Report_Forms_Ref_Katos_RefKatoId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report_Forms"
    ADD CONSTRAINT "FK_Report_Forms_Ref_Katos_RefKatoId" FOREIGN KEY ("RefKatoId") REFERENCES public."Ref_Katos"("Id") ON DELETE CASCADE;


--
-- Name: Report_Forms FK_Report_Forms_Ref_Statuses_RefStatusId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report_Forms"
    ADD CONSTRAINT "FK_Report_Forms_Ref_Statuses_RefStatusId" FOREIGN KEY ("RefStatusId") REFERENCES public."Ref_Statuses"("Id") ON DELETE CASCADE;


--
-- Name: SeloDocuments FK_SeloDocuments_SeloForms_SeloFormId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SeloDocuments"
    ADD CONSTRAINT "FK_SeloDocuments_SeloForms_SeloFormId" FOREIGN KEY ("SeloFormId") REFERENCES public."SeloForms"("Id");


--
-- Name: Suppliers FK_Suppliers_Ref_Katos_KatoId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Suppliers"
    ADD CONSTRAINT "FK_Suppliers_Ref_Katos_KatoId" FOREIGN KEY ("KatoId") REFERENCES public."Ref_Katos"("Id") ON DELETE CASCADE;


--
-- Name: Tariff_Level FK_Tariff_Level_Report_Forms_FormId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Tariff_Level"
    ADD CONSTRAINT "FK_Tariff_Level_Report_Forms_FormId" FOREIGN KEY ("FormId") REFERENCES public."Report_Forms"("Id") ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

